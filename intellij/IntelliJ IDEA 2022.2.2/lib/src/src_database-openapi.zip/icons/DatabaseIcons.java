/*
 * Copyright 2000-2016 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package icons;

import com.intellij.ui.IconManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public final class DatabaseIcons {
  private static @NotNull Icon load(@NotNull String path, int cacheKey, int flags) {
    return IconManager.getInstance().loadRasterizedIcon(path, DatabaseIcons.class.getClassLoader(), cacheKey, flags);
  }
  /** 16x16 */ public static final @NotNull Icon Access_method = load("icons/access_method.svg", 251568751, 0);
  /** 16x16 */ public static final @NotNull Icon Adapter_script = load("icons/adapter_script.svg", 1601107856, 0);
  /** 10x10 */ public static final @NotNull Icon AddHover = load("icons/add-hover.svg", -616527728, 2);
  /** 10x10 */ public static final @NotNull Icon Add = load("icons/add.svg", -588944407, 2);
  /** 16x16 */ public static final @NotNull Icon Aggregate = load("icons/aggregate.svg", 514874938, 0);
  /** 16x16 */ public static final @NotNull Icon Argument = load("icons/argument.svg", -940393681, 0);
  /** 16x16 */ public static final @NotNull Icon BinaryData = load("icons/binaryData.svg", -1993673978, 2);
  /** 16x16 */ public static final @NotNull Icon BlueKey = load("icons/blueKey.svg", -195961313, 0);
  /** 16x16 */ public static final @NotNull Icon BlueKeyTrigger = load("icons/blueKeyTrigger.svg", -1871841936, 0);
  /** 16x16 */ public static final @NotNull Icon Body = load("icons/body.svg", -1757923734, 0);
  /** 16x16 */ public static final @NotNull Icon CheckConstraint = load("icons/checkConstraint.svg", -1000302704, 0);
  /** 16x16 */ public static final @NotNull Icon Col = load("icons/col.svg", 71255462, 0);
  /** 16x16 */ public static final @NotNull Icon ColBlueKey = load("icons/colBlueKey.svg", -1620478450, 0);
  /** 16x16 */ public static final @NotNull Icon ColBlueKeyDot = load("icons/colBlueKeyDot.svg", 514657989, 2);
  /** 16x16 */ public static final @NotNull Icon ColBlueKeyDotIndex = load("icons/colBlueKeyDotIndex.svg", 1117403593, 2);
  /** 16x16 */ public static final @NotNull Icon ColBlueKeyIndex = load("icons/colBlueKeyIndex.svg", -2110090904, 0);
  /** 16x16 */ public static final @NotNull Icon ColDot = load("icons/colDot.svg", 757640874, 2);
  /** 16x16 */ public static final @NotNull Icon ColDotIndex = load("icons/colDotIndex.svg", -2087290813, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKey = load("icons/colGoldBlueKey.svg", 987362170, 0);
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKeyDot = load("icons/colGoldBlueKeyDot.svg", 460451277, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKeyDotIndex = load("icons/colGoldBlueKeyDotIndex.svg", -727568186, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKeyIndex = load("icons/colGoldBlueKeyIndex.svg", -1090738525, 0);
  /** 16x16 */ public static final @NotNull Icon ColGoldKey = load("icons/colGoldKey.svg", -1243680002, 0);
  /** 16x16 */ public static final @NotNull Icon ColGoldKeyDot = load("icons/colGoldKeyDot.svg", -2040998966, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldKeyDotIndex = load("icons/colGoldKeyDotIndex.svg", 502498413, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldKeyIndex = load("icons/colGoldKeyIndex.svg", -1748513918, 0);
  /** 16x16 */ public static final @NotNull Icon ColGreyKey = load("icons/colGreyKey.svg", 313035889, 0);
  /** 16x16 */ public static final @NotNull Icon ColIndex = load("icons/colIndex.svg", -116540998, 0);
  /** 16x16 */ public static final @NotNull Icon Collation = load("icons/collation.svg", -585309616, 0);
  /** 16x16 */ public static final @NotNull Icon CollectionType = load("icons/collectionType.svg", -1118446023, 0);
  /** 16x16 */ public static final @NotNull Icon Connector = load("icons/connector.svg", 2007555148, 0);
  /** 16x16 */ public static final @NotNull Icon ConsoleRun = load("icons/consoleRun.svg", 1817651612, 2);
  /** 16x16 */ public static final @NotNull Icon ConsoleShowPlan = load("icons/consoleShowPlan.svg", 1011240332, 2);
  /** 16x16 */ public static final @NotNull Icon Constant = load("icons/constant.svg", 1868047068, 0);
  /** 16x16 */ public static final @NotNull Icon Database = load("icons/database.svg", 475857573, 0);
  /** 16x16 */ public static final @NotNull Icon DatabaseLink = load("icons/databaseLink.svg", 1375301208, 2);
  /** 16x16 */ public static final @NotNull Icon DatabaseObjGroup = load("icons/databaseObjGroup.svg", -1231533775, 0);
  /** 16x16 */ public static final @NotNull Icon DataFile = load("icons/dataFile.svg", -1168578334, 0);
  /** 16x16 */ public static final @NotNull Icon Dbms = load("icons/dbms.svg", 1882623053, 0);
  /** 16x16 */ public static final @NotNull Icon DdlDbms = load("icons/ddlDbms.svg", 1548639435, 1);
  /** 16x16 */ public static final @NotNull Icon DefaultConstraint = load("icons/defaultConstraint.svg", -1348864492, 0);
  /** 16x16 */ public static final @NotNull Icon DriverBlue1 = load("icons/driverBlue1.svg", -1208265086, 0);
  /** 16x16 */ public static final @NotNull Icon DriverBlue2 = load("icons/driverBlue2.svg", 233965304, 0);
  /** 16x16 */ public static final @NotNull Icon DriverBlue3 = load("icons/driverBlue3.svg", 274201167, 0);
  /** 16x16 */ public static final @NotNull Icon DriverBlue4 = load("icons/driverBlue4.svg", 640074556, 0);
  /** 16x16 */ public static final @NotNull Icon DriverGreen1 = load("icons/driverGreen1.svg", 1774340318, 0);
  /** 16x16 */ public static final @NotNull Icon DriverGreen2 = load("icons/driverGreen2.svg", 1399521782, 0);
  /** 16x16 */ public static final @NotNull Icon DriverGreen3 = load("icons/driverGreen3.svg", 694043169, 0);
  /** 16x16 */ public static final @NotNull Icon DriverGreen4 = load("icons/driverGreen4.svg", -235678167, 0);
  /** 16x16 */ public static final @NotNull Icon DriverPink1 = load("icons/driverPink1.svg", -170544126, 0);
  /** 16x16 */ public static final @NotNull Icon DriverPink2 = load("icons/driverPink2.svg", 1267501240, 0);
  /** 16x16 */ public static final @NotNull Icon DriverPink3 = load("icons/driverPink3.svg", -1713259497, 0);
  /** 16x16 */ public static final @NotNull Icon DriverPink4 = load("icons/driverPink4.svg", -8020521, 0);
  /** 16x16 */ public static final @NotNull Icon DriverRed1 = load("icons/driverRed1.svg", -1050950953, 0);
  /** 16x16 */ public static final @NotNull Icon DriverRed2 = load("icons/driverRed2.svg", 307904507, 0);
  /** 16x16 */ public static final @NotNull Icon DriverRed3 = load("icons/driverRed3.svg", -981493790, 0);
  /** 16x16 */ public static final @NotNull Icon DriverRed4 = load("icons/driverRed4.svg", -1832504896, 0);
  /** 16x16 */ public static final @NotNull Icon EditorOutput = load("icons/editorOutput.svg", -502424860, 2);
  /** 16x16 */ public static final @NotNull Icon Extension = load("icons/extension.svg", 1149983867, 0);
  /** 16x16 */ public static final @NotNull Icon External_schema_object = load("icons/external_schema_object.svg", -862820440, 2);
  /** 16x16 */ public static final @NotNull Icon FileFormat = load("icons/fileFormat.svg", 1133710806, 0);
  /** 16x16 */ public static final @NotNull Icon FilterHistory = load("icons/filterHistory.svg", 1265903771, 0);
  /** 16x16 */ public static final @NotNull Icon Foreign_datawrapper = load("icons/foreign_datawrapper.svg", -1647676334, 2);
  /** 16x16 */ public static final @NotNull Icon Foreign_server = load("icons/foreign_server.svg", -1534526140, 2);
  /** 16x16 */ public static final @NotNull Icon Foreign_table = load("icons/foreign_table.svg", 376949166, 2);
  /** 16x16 */ public static final @NotNull Icon Function = load("icons/function.svg", 1037974215, 1);
  /** 16x16 */ public static final @NotNull Icon FunctionRun = load("icons/functionRun.svg", 1020646209, 1);
  /** 16x16 */ public static final @NotNull Icon GoldKey = load("icons/goldKey.svg", -213750803, 0);
  /** 16x16 */ public static final @NotNull Icon GoldKeyAlt = load("icons/goldKeyAlt.svg", 1577344468, 0);
  /** 16x16 */ public static final @NotNull Icon GreenBugOverlap = load("icons/greenBugOverlap.svg", 22896964, 2);
  /** 16x16 */ public static final @NotNull Icon HashCluster = load("icons/hashCluster.svg", 709958179, 2);
  /** 16x16 */ public static final @NotNull Icon Index = load("icons/index.svg", 642556724, 0);
  /** 16x16 */ public static final @NotNull Icon IndexCluster = load("icons/indexCluster.svg", 1838950170, 0);
  /** 16x16 */ public static final @NotNull Icon IndexFun = load("icons/indexFun.svg", -1722674649, 2);
  /** 16x16 */ public static final @NotNull Icon IndexUnique = load("icons/indexUnique.svg", 1741168621, 2);
  /** 16x16 */ public static final @NotNull Icon IndexUniqueFun = load("icons/indexUniqueFun.svg", -1368428658, 2);
  /** 16x16 */ public static final @NotNull Icon KillDataSourceProcess = load("icons/killDataSourceProcess.svg", -1368553704, 2);
  /** 12x16 */ public static final @NotNull Icon Level1 = load("icons/level1.svg", 877589076, 0);
  /** 16x16 */ public static final @NotNull Icon Level1_declared = load("icons/level1_declared.svg", 851634337, 2);
  /** 16x16 */ public static final @NotNull Icon Level1_details = load("icons/level1_details.svg", -249180349, 0);
  /** 16x16 */ public static final @NotNull Icon Level1_inherited = load("icons/level1_inherited.svg", 771950090, 2);
  /** 12x16 */ public static final @NotNull Icon Level2 = load("icons/level2.svg", 343602521, 0);
  /** 16x16 */ public static final @NotNull Icon Level2_declared = load("icons/level2_declared.svg", -677413881, 2);
  /** 16x16 */ public static final @NotNull Icon Level2_details = load("icons/level2_details.svg", -1672963287, 0);
  /** 16x16 */ public static final @NotNull Icon Level2_inherited = load("icons/level2_inherited.svg", -625673760, 2);
  /** 12x16 */ public static final @NotNull Icon Level3 = load("icons/level3.svg", -923862180, 0);
  /** 16x16 */ public static final @NotNull Icon Level3_declared = load("icons/level3_declared.svg", -463401334, 2);
  /** 16x16 */ public static final @NotNull Icon Level3_details = load("icons/level3_details.svg", 1861780612, 0);
  /** 16x16 */ public static final @NotNull Icon Level3_inherited = load("icons/level3_inherited.svg", -771188677, 2);
  /** 16x16 */ public static final @NotNull Icon Macro = load("icons/macro.svg", 1871564197, 1);
  /** 16x16 */ public static final @NotNull Icon ManageDataSources = load("icons/manageDataSources.svg", -1262990154, 2);
  /** 16x16 */ public static final @NotNull Icon MaterializedLog = load("icons/materializedLog.svg", 737748128, 2);
  /** 16x16 */ public static final @NotNull Icon MaterializedView = load("icons/materializedView.svg", -2035734627, 2);
  /** 16x16 */ public static final @NotNull Icon MongoField = load("icons/mongoField.svg", -2142417831, 0);
  /** 16x16 */ public static final @NotNull Icon MongoFieldGoldKey = load("icons/mongoFieldGoldKey.svg", -1448980098, 0);
  /** 16x16 */ public static final @NotNull Icon ObjectGroup = load("icons/objectGroup.svg", 1440437805, 0);
  /** 16x16 */ public static final @NotNull Icon Operator = load("icons/operator.svg", 1219777547, 0);
  /** 16x16 */ public static final @NotNull Icon OperatorClass = load("icons/operatorClass.svg", -65770697, 0);
  /** 16x16 */ public static final @NotNull Icon OperatorFamily = load("icons/operatorFamily.svg", -1236962613, 0);
  /** 16x16 */ public static final @NotNull Icon Package = load("icons/package.svg", 2097135839, 0);
  /** 16x16 */ public static final @NotNull Icon Partition = load("icons/partition.svg", 1720348060, 0);
  /** 16x16 */ public static final @NotNull Icon PreviewChanges = load("icons/previewChanges.svg", -1531327693, 2);
  /** 16x16 */ public static final @NotNull Icon Procedure = load("icons/procedure.svg", 1845240964, 0);
  /** 16x16 */ public static final @NotNull Icon ProcedureRun = load("icons/procedureRun.svg", -1792506121, 0);
  /** 16x16 */ public static final @NotNull Icon ProcGroup = load("icons/procGroup.svg", -709348781, 1);
  /** 16x16 */ public static final @NotNull Icon Projection = load("icons/projection.svg", 784971408, 2);
  /** 16x16 */ public static final @NotNull Icon Role = load("icons/role.svg", -465112656, 0);
  /** 16x16 */ public static final @NotNull Icon RollbackDB = load("icons/rollbackDB.svg", -1328359705, 2);
  /** 16x16 */ public static final @NotNull Icon Routine = load("icons/routine.svg", 1414690170, 0);
  /** 16x16 */ public static final @NotNull Icon Rule = load("icons/rule.svg", -1209458994, 0);
  /** 16x16 */ public static final @NotNull Icon RunDatabaseScript = load("icons/runDatabaseScript.svg", -1989326979, 2);
  /** 16x16 */ public static final @NotNull Icon ScheduledEvent = load("icons/scheduledEvent.svg", -1120904475, 0);
  /** 16x16 */ public static final @NotNull Icon Schema = load("icons/schema.svg", -970077165, 0);
  /** 16x16 */ public static final @NotNull Icon Scripting_script = load("icons/scripting_script.svg", -472916873, 2);
  /** 16x16 */ public static final @NotNull Icon Sequence = load("icons/sequence.svg", -1753924298, 0);
  /** 16x16 */ public static final @NotNull Icon ServerObjGroup = load("icons/serverObjGroup.svg", 706621129, 0);
  /** 16x16 */ public static final @NotNull Icon SortHistory = load("icons/sortHistory.svg", -546415619, 0);
  /** 16x16 */ public static final @NotNull Icon Sql = load("icons/sql.svg", -85778380, 0);
  /** 16x16 */ public static final @NotNull Icon SqlDmlStatement = load("icons/sqlDmlStatement.svg", -809586184, 0);
  /** 16x16 */ public static final @NotNull Icon SqlGroupByType = load("icons/sqlGroupByType.svg", -249579520, 2);
  /** 16x16 */ public static final @NotNull Icon SqlOtherStatement = load("icons/sqlOtherStatement.svg", 1794799639, 0);
  /** 16x16 */ public static final @NotNull Icon SqlSelectStatement = load("icons/sqlSelectStatement.svg", 1989660104, 0);
  /** 16x16 */ public static final @NotNull Icon SubmitDB = load("icons/submitDB.svg", -1181032956, 2);
  /** 16x16 */ public static final @NotNull Icon SuspendScaled = load("icons/suspendScaled.svg", -128017805, 2);
  /** 16x16 */ public static final @NotNull Icon Synonym = load("icons/synonym.svg", 560861377, 2);
  /** 16x16 */ public static final @NotNull Icon Table = load("icons/table.svg", -478555948, 0);
  /** 16x16 */ public static final @NotNull Icon Tablespace = load("icons/tablespace.svg", 1712970410, 0);
  /** 16x16 */ public static final @NotNull Icon TextAutoGenerate = load("icons/textAutoGenerate.svg", -1636251454, 2);
  /** 13x13 */ public static final @NotNull Icon ToolWindowConsole = load("icons/toolWindowConsole.svg", 388000058, 2);
  /** 13x13 */ public static final @NotNull Icon ToolWindowDatabase = load("icons/toolWindowDatabase.svg", -573876225, 2);
  /** 13x13 */ public static final @NotNull Icon ToolwindowDatabaseChanges = load("icons/toolwindowDatabaseChanges.svg", -1143616902, 2);
  /** 13x13 */ public static final @NotNull Icon ToolWindowFiles = load("icons/toolWindowFiles.svg", 208534587, 2);
  /** 13x13 */ public static final @NotNull Icon ToolWindowSQLGenerator = load("icons/toolWindowSQLGenerator.svg", -197426343, 2);
  /** 16x16 */ public static final @NotNull Icon Trigger = load("icons/trigger.svg", 539924718, 0);
  /** 16x16 */ public static final @NotNull Icon TSQLt = load("icons/tSQLt.svg", -927326739, 0);
  /** 16x16 */ public static final @NotNull Icon Udf_script = load("icons/udf_script.svg", 148355269, 2);
  /** 16x16 */ public static final @NotNull Icon UnspecifiedCluster = load("icons/unspecifiedCluster.svg", -1090556696, 0);
  /** 16x16 */ public static final @NotNull Icon User_mapping = load("icons/user_mapping.svg", 1481813066, 0);
  /** 16x16 */ public static final @NotNull Icon UserDriver = load("icons/userDriver.svg", -2119303308, 0);
  /** 16x16 */ public static final @NotNull Icon UtPLSQL = load("icons/utPLSQL.svg", -128646760, 0);
  /** 16x16 */ public static final @NotNull Icon Warehouse = load("icons/warehouse.svg", 420873097, 0);
}

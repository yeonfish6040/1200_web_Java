package com.intellij.sql.psi;

import org.jetbrains.annotations.NotNull;

public interface SqlColumnDetailsClause extends SqlClause {
  @NotNull
  SqlReferenceExpression getColumnRef();
}

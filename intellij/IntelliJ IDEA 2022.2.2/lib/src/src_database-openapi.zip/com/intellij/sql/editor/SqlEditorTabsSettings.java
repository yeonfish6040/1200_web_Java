package com.intellij.sql.editor;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.PersistentStateComponent;
import com.intellij.openapi.components.SettingsCategory;
import com.intellij.openapi.components.State;
import com.intellij.openapi.components.Storage;
import com.intellij.util.xmlb.XmlSerializerUtil;
import com.intellij.util.xmlb.annotations.Attribute;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@State(name = "SqlEditorTabsSettings", storages = @Storage("editor.xml"), category = SettingsCategory.CODE)
public class SqlEditorTabsSettings implements PersistentStateComponent<SqlEditorTabsSettings> {
  @Attribute("ALWAYS_QUALIFY_TAB_NAMES")
  private volatile boolean myAlwaysQualifyTabNames = false;

  @Attribute("SHORTEN_TAB_NAMES")
  private volatile boolean myShortenTabNames = true;

  @Nullable
  @Override
  public SqlEditorTabsSettings getState() {
    return this;
  }

  @Override
  public void loadState(@NotNull SqlEditorTabsSettings state) {
    XmlSerializerUtil.copyBean(state, this);
  }

  public boolean isAlwaysQualifyTabNames() {
    return myAlwaysQualifyTabNames;
  }

  public void setAlwaysQualifyTabNames(boolean alwaysQualifyTabNames) {
    myAlwaysQualifyTabNames = alwaysQualifyTabNames;
  }

  public boolean isShortenTabNames() {
    return myShortenTabNames;
  }

  public void setShortenTabNames(boolean shortenTabNames) {
    myShortenTabNames = shortenTabNames;
  }

  @NotNull
  public static SqlEditorTabsSettings getInstance() {
    return ApplicationManager.getApplication().getService(SqlEditorTabsSettings.class);
  }
}

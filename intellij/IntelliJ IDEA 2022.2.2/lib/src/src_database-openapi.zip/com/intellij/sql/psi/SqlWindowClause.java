package com.intellij.sql.psi;

public interface SqlWindowClause extends SqlClause {
}

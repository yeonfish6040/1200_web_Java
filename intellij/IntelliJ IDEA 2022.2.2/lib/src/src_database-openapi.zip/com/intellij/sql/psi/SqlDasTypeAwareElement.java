package com.intellij.sql.psi;

import com.intellij.database.model.DasTypeAwareObject;

public interface SqlDasTypeAwareElement extends SqlElement, DasTypeAwareObject {
  
}
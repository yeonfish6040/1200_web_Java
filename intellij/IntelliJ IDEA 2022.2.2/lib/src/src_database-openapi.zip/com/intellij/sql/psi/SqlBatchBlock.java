package com.intellij.sql.psi;

/**
 * @author gregsh
 */
public interface SqlBatchBlock extends SqlElement {
}

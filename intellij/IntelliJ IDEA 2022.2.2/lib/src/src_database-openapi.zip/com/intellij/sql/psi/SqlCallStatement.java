package com.intellij.sql.psi;

public interface SqlCallStatement extends SqlStatement {
}

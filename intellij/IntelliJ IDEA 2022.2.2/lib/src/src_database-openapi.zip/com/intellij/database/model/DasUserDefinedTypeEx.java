package com.intellij.database.model;

public interface DasUserDefinedTypeEx extends DasUserDefinedType, DasTypeAwareObject {
  
}

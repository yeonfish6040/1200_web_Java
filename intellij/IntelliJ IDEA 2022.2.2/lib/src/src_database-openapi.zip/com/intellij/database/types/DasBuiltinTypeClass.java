package com.intellij.database.types;

import org.jetbrains.annotations.NotNull;

public interface DasBuiltinTypeClass<C extends DasTypeClass> extends DasTypeClass {
  enum Kind {
    NUMBER,
    BOOLEAN,
    DATE,
    TIME,
    DATE_TIME,
    TIMESTAMP,
    INTERVAL,
    STRING,
    BINARY,
    ENUM,
    NULL,
    VOID,
    MISC,
    UNKNOWN
  }

  @NotNull
  Kind getKind();

  @NotNull
  DasBuiltinTypeClass<C> getCanonical();

  @NotNull
  C withName(@NotNull String newName);
}

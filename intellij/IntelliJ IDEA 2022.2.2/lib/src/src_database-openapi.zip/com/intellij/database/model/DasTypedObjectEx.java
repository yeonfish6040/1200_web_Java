package com.intellij.database.model;

public interface DasTypedObjectEx extends DasTypedObject, DasTypeAwareObject {
  
}

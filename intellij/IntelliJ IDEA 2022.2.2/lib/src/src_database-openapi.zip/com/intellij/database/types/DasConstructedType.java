package com.intellij.database.types;

public interface DasConstructedType extends DasType {
}

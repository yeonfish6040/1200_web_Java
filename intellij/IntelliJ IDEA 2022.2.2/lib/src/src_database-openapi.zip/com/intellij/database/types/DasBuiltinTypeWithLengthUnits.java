package com.intellij.database.types;

import com.intellij.database.model.LengthUnit;
import com.intellij.database.model.SizeConstant;
import org.jetbrains.annotations.NotNull;

public interface DasBuiltinTypeWithLengthUnits<C extends DasBuiltinTypeClass<C>> extends DasBuiltinTypeWithLength<C> {
  @NotNull
  LengthUnit getUnit();

  boolean isExplicitUnit();

  @NotNull
  DasBuiltinTypeWithLengthUnits<C> copy(@SizeConstant int length, @NotNull LengthUnit unit, boolean isExplicitUnit);
}
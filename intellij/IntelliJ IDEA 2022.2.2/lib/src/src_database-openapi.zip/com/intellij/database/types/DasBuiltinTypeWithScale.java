package com.intellij.database.types;

import com.intellij.database.model.ScaleConstant;
import org.jetbrains.annotations.NotNull;

public interface DasBuiltinTypeWithScale<C extends DasBuiltinTypeClass<C>> extends DasBuiltinType<C> {
  @ScaleConstant
  int getScale();

  @NotNull
  DasBuiltinTypeWithScale<C> copy(@ScaleConstant int scale);
}
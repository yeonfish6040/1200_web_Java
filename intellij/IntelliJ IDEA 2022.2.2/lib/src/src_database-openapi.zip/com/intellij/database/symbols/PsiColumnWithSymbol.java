package com.intellij.database.symbols;

import com.intellij.database.model.PsiColumn;

public interface PsiColumnWithSymbol extends DasColumnSymbol, PsiColumn {
}

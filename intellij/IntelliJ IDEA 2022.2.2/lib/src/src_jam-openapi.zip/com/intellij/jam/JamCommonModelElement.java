package com.intellij.jam;

import com.intellij.jam.model.common.CommonModelElement;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiElementRef;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public abstract class JamCommonModelElement<T extends PsiElement> extends CommonModelElement.PsiBase implements JamElement {
  private final Object myAnchor;

  protected JamCommonModelElement(PsiElementRef<?> ref) {
    myAnchor = JamRefService.getInstance().createAnchor(ref);
  }

  @SuppressWarnings("unchecked")
  public @NotNull PsiElementRef<T> getPsiElementRef() {
    return (PsiElementRef<T>)JamRefService.getInstance().retrieve(myAnchor);
  }

  @Override
  @SuppressWarnings("unchecked")
  public @NotNull T getPsiElement() {
    PsiElementRef<?> ref = getPsiElementRef();
    return (T)Objects.requireNonNull(ref.getPsiElement());
  }

  @Override
  public boolean isValid() {
    return JamRefService.getInstance().isValid(myAnchor);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof JamCommonModelElement)) return false;

    JamCommonModelElement that = (JamCommonModelElement)o;

    if (!getClass().equals(that.getClass())) return false;
    if (!myAnchor.equals(that.myAnchor)) return false;

    return true;
  }

  @Override
  public int hashCode() {
    int result = getClass().hashCode();
    result = 31 * result + myAnchor.hashCode();
    return result;
  }

  @Override
  public String toString() {
    return getClass().getSimpleName() + "{" +
           " myRef=" + myAnchor +
           "}";
  }
}

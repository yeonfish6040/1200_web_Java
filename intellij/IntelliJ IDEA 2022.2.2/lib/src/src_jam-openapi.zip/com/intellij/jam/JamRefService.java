package com.intellij.jam;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.psi.PsiElementRef;

public interface JamRefService {
  Object createAnchor(PsiElementRef<?> ref);

  PsiElementRef<?> retrieve(Object anchor);

  boolean isValid(Object anchor);

  static JamRefService getInstance() {
    return ApplicationManager.getApplication().getService(JamRefService.class);
  }
}

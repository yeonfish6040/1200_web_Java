package com.intellij.jam.view.ui;

import com.intellij.jam.view.tree.JamAbstractTreeBuilder;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiElement;
import org.jetbrains.annotations.Nls;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;

public abstract class JamUi {
  @NotNull
  public abstract ProgressIndicator createTreeBuilderProgressIndicator(@NotNull JamAbstractTreeBuilder builder);

  public static JamUi getInstance() {
    return ApplicationManager.getApplication().getService(JamUi.class);
  }

  public abstract Collection<PsiElement> chooseJamElements(Project project,
                                                           @NotNull Collection<? extends PsiElement> elements,
                                                           @NotNull @Nls final String title,
                                                           @NotNull @Nls final String elementsTitle);

  public abstract Collection<PsiElement> chooseJamElementsToDelete(Project project,
                                                                   @NotNull Collection<? extends PsiElement> ownedReferences);
}

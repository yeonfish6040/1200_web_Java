package com.intellij.jam;

import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiElementRef;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public abstract class JamBaseElement<T extends PsiElement> implements JamElement {
  private final Object myAnchor;

  protected JamBaseElement(PsiElementRef<?> ref) {
    myAnchor = JamRefService.getInstance().createAnchor(ref);
  }

  @SuppressWarnings("unchecked")
  public @NotNull PsiElementRef<T> getPsiElementRef() {
    return (PsiElementRef<T>)JamRefService.getInstance().retrieve(myAnchor);
  }

  @SuppressWarnings("unchecked")
  public @NotNull T getPsiElement() {
    PsiElementRef<?> ref = getPsiElementRef();
    return (T)Objects.requireNonNull(ref.getPsiElement());
  }

  public boolean isValid() {
    return JamRefService.getInstance().isValid(myAnchor);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof JamBaseElement)) return false;

    JamBaseElement that = (JamBaseElement)o;

    if (!getClass().equals(that.getClass())) return false;
    if (!myAnchor.equals(that.myAnchor)) return false;

    return true;
  }

  @Override
  public int hashCode() {
    int result = getClass().hashCode();
    result = 31 * result + myAnchor.hashCode();
    return result;
  }

  @Override
  public String toString() {
    return getClass().getSimpleName() + "{" +
           " myRef=" + myAnchor +
           "}";
  }
}

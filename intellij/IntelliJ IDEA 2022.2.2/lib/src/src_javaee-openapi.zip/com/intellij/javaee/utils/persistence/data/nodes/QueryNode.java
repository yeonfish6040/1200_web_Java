package com.intellij.javaee.utils.persistence.data.nodes;


import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.Set;

public abstract class QueryNode {

    public static final String AND = "And";
    public static final String OR = "Or";
    public static final String ORDER_BY = "OrderBy";


    private final String myExpression;

    protected QueryNode(@NotNull String expression) {
        myExpression = expression;
    }

    @NotNull
    public Set<? extends QueryNode> getChildren() {
        return Collections.emptySet();
    }

    public String getExpression() {
        return myExpression;
    }
}

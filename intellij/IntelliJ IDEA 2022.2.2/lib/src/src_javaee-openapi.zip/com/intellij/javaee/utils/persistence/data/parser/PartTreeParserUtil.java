package com.intellij.javaee.utils.persistence.data.parser;

import com.intellij.javaee.utils.persistence.data.parser.domain.OrderBySource;
import com.intellij.javaee.utils.persistence.data.parser.domain.Sort;
import com.intellij.openapi.util.TextRange;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class PartTreeParserUtil {

  @NotNull
  public static Map<Part, TextRange> getPartTextRanges(@NotNull PartTree partTree) {
    Map<Part, TextRange> textRanges = new HashMap<>();
    String methodName = partTree.getSource();
    PartTree.Subject subject = partTree.getSubject();
    int previousPartEndOffset = subject != null && subject.getExpression() != null ? subject.getExpression().length() : 0;
    for (PartTree.OrPart orPart : partTree) {
      Iterator<Part> iterator = orPart.iterator();
      while (iterator.hasNext()) {
        Part part = iterator.next();
        int startOffset = methodName.indexOf(part.getSource(), previousPartEndOffset);
        TextRange range = TextRange.create(startOffset, startOffset + part.getSource().length());
        textRanges.put(part, range);

        previousPartEndOffset = range.getEndOffset() +  (iterator.hasNext() ? "And".length() : "Or".length());
      }
    }
    return textRanges;
  }

  @NotNull
  public static Map<Sort.Order, TextRange> getSortTextRanges(@NotNull PartTree partTree) {
    Map<Sort.Order, TextRange> textRanges = new HashMap<>();
    String methodName = partTree.getSource();
    OrderBySource orderBy = partTree.getOrderBySource();

    if (orderBy != null) {
      TextRange lastTextRange = TextRange.create(0, partTree.getSource().indexOf("OrderBy" + orderBy.getSource()));
      for (TextRange range : getPartTextRanges(partTree).values()) {
        if (lastTextRange.getEndOffset() < range.getEndOffset()) {
          lastTextRange = range;
        }
      }

      for (Sort.Order order : orderBy.getOrders()) {
        int startOffset = methodName.indexOf(StringUtil.capitalize(order.getPropertySourceExpression()), lastTextRange.getEndOffset());
        TextRange range = TextRange.create(startOffset, startOffset + order.getSortExpression().length());
        textRanges.put(order, range);

        lastTextRange = range;
      }
    }

    return textRanges;
  }
}

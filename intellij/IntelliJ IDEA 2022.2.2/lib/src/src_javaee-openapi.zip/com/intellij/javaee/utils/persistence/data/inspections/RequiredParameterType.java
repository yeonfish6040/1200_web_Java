package com.intellij.javaee.utils.persistence.data.inspections;

import com.intellij.javaee.utils.persistence.data.parser.domain.PropertyPath;
import com.intellij.psi.PsiType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.Set;

public class RequiredParameterType {
  public @NotNull PropertyPath propertyPath;
  public @Nullable PsiType type;
  @NotNull Set<PartTreeInconsistencyUtils.AssignableParameterTypeValidator> assignableTypeValidators = Collections.emptySet();

  public final boolean collectionType;
  public final boolean collectionElementType;

  private RequiredParameterType(@NotNull PropertyPath path,
                                @Nullable PsiType type,
                                boolean collectionType,
                                boolean collectionElementType) {
    this.type = type;
    this.collectionElementType = collectionElementType;
    this.collectionType = collectionType;
    this.propertyPath = path;
  }

  public static RequiredParameterType simple(@NotNull PropertyPath path, @Nullable PsiType type) {
    return new RequiredParameterType(path, type, false, false);
  }

  public static RequiredParameterType collectionType(@NotNull PropertyPath path, @Nullable PsiType type) {
    return new RequiredParameterType(path, type, true, false);
  }

  public static RequiredParameterType collectionElementType(@NotNull PropertyPath path, @Nullable PsiType type) {
    return new RequiredParameterType(path, type, false, true);
  }
}

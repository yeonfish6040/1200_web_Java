/*
 * Copyright 2008-2015 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.utils.persistence.data.parser;

import com.intellij.javaee.utils.persistence.data.parser.domain.PropertyPath;
import com.intellij.psi.JavaPsiFacade;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiSubstitutor;
import org.jetbrains.annotations.NotNull;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A single part of a method name that has to be transformed into a query part. The actual transformation is defined by
 * a {@link PartType} that is determined from inspecting the given part. The query part can then be looked up via
 * {@link #getProperty()}.
 *
 * @author Oliver Gierke
 * @author Martin Baumgartner
 */
public class Part {

  private static final Pattern IGNORE_CASE = Pattern.compile("Ignor(ing|e)Case");

  private final PropertyPath propertyPath;
  private final PartType type;

  private IgnoreCaseType ignoreCase = IgnoreCaseType.NEVER;
  private final String mySource;
  private final PartTreeParserContext myParserContext;

  /**
   * Creates a new {@link Part} from the given method name part, the {@link Class} the part originates from and the
   * start parameter index.
   *
   * @param source           must not be {@literal null}.
   * @param clazz            must not be {@literal null}.
   * @param alwaysIgnoreCase
   * @param parserContext
   */
  public Part(String source,
              PsiClass clazz,
              boolean alwaysIgnoreCase,
              PartTreeParserContext parserContext) {
    mySource = source;
    myParserContext = parserContext;
    String partToUse = detectAndSetIgnoreCase(source);
    if (alwaysIgnoreCase && ignoreCase != IgnoreCaseType.ALWAYS) {
      this.ignoreCase = IgnoreCaseType.WHEN_POSSIBLE;
    }
    this.type = myParserContext.types().fromProperty(partToUse);
    this.propertyPath = PropertyPath.from(type.extractProperty(partToUse), JavaPsiFacade
      .getElementFactory(clazz.getProject()).createType(clazz, PsiSubstitutor.EMPTY));
  }

  @NotNull
  private String detectAndSetIgnoreCase(@NotNull String part) {
    Matcher matcher = IGNORE_CASE.matcher(part);
    String result = part;

    if (matcher.find()) {
      ignoreCase = IgnoreCaseType.ALWAYS;
      result = part.substring(0, matcher.start()) + part.substring(matcher.end());
    }

    return result;
  }

  public boolean getParameterRequired() {
    return getNumberOfArguments() > 0;
  }

  /**
   * Returns how many method parameters are bound by this part.
   *
   * @return
   */
  public int getNumberOfArguments() {
    return type.getNumberOfArguments();
  }

  /**
   * @return the propertyPath
   */
  public PropertyPath getProperty() {
    return propertyPath;
  }

  /**
   * @return the type
   */
  public PartType getType() {
    return type;
  }

  /**
   * Returns whether the {@link PropertyPath} referenced should be matched ignoring case.
   *
   * @return
   */
  public IgnoreCaseType shouldIgnoreCase() {
    return ignoreCase;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj) {
    if (obj == this) {
      return true;
    }

    if (obj == null || !getClass().equals(obj.getClass())) {
      return false;
    }

    Part that = (Part)obj;
    return this.propertyPath.equals(that.propertyPath) && this.type.equals(that.type);
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode() {
    int result = 37;
    result += 17 * propertyPath.hashCode();
    result += 17 * type.hashCode();
    return result;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "PART ('" + mySource + "'," + type.name() + ")";
  }

  public String getSource() {
    return mySource;
  }

  /**
   * The various types of ignore case that are supported.
   *
   * @author Phillip Webb
   */
  public enum IgnoreCaseType {
    /**
     * Should not ignore the sentence case.
     */
    NEVER,

    /**
     * Should ignore the sentence case, throwing an exception if this is not possible.
     */
    ALWAYS,

    /**
     * Should ignore the sentence case when possible to do so, silently ignoring the option when not possible.
     */
    WHEN_POSSIBLE
  }
}
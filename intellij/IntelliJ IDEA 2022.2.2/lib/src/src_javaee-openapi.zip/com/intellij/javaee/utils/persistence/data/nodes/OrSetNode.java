package com.intellij.javaee.utils.persistence.data.nodes;

import com.intellij.util.Function;
import org.jetbrains.annotations.NotNull;

public class OrSetNode extends ContainerNode {

    public OrSetNode(@NotNull String expression) {
        super(expression);

    }

    @Override
    protected Function<String, QueryNode> getChildrenFactory() {
        return OrNode::new;
    }

    @Override
    protected String getChildrenNodesDelimiter() {
        return OR;
    }

}

package com.intellij.javaee.utils.persistence.data.nodes;

import com.intellij.openapi.util.text.StringUtil;
import com.intellij.util.Processor;
import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SelectPropertyNode extends PropertyNode {
    private static final Pattern IGNORE_CASE = Pattern.compile("Ignor(ing|e)Case");

    private String myPropertyName;
    private PropertyParametersType myType = PropertyParametersType.SIMPLE_PROPERTY;

    public SelectPropertyNode(@NotNull final String expression) {
        super(expression);
        final String expressionCaseProcessed = detectAndSetIgnoreCase(expression);
        myPropertyName = StringUtil.decapitalize(expressionCaseProcessed);
        final Processor<PropertyParametersType> processor = type -> {
            for (String keyword : type.getKeywords()) {
                if (expressionCaseProcessed.endsWith(keyword)) {
                    myType = type;
                    myPropertyName = StringUtil.decapitalize(expressionCaseProcessed.substring(0, expressionCaseProcessed.indexOf(keyword)));
                    return false;
                }
            }
            return true;
        };

        for (PropertyParametersType type : PropertyParametersType.ALL) {
            if (!processor.process(type)) break;
        }
    }

    @Override
    public String getPropertyName() {
        return myPropertyName;
    }

    @Override
    public boolean isDefaultKeyword() {
        return myType == PropertyParametersType.SIMPLE_PROPERTY;
    }

    public PropertyParametersType getType() {
        return myType;
    }

    @Override
    public Set<String> getPropertyKeywords() {
        HashSet<String> strings = new HashSet<>();
        for (PropertyParametersType type : PropertyParametersType.ALL) {
          Collections.addAll(strings, type.getKeywords());
        }
        return strings;
    }

    @NotNull
    @Override
    public String getKeyword() {
        return getExpression().substring(myPropertyName.length());
    }

    @NotNull
    private static String detectAndSetIgnoreCase(@NotNull String expression) {
        Matcher matcher = IGNORE_CASE.matcher(expression);
        String result = expression;

        if (matcher.find()) {
            result = expression.substring(0, matcher.start()) + expression.substring(matcher.end());
        }

        return result;
    }

}

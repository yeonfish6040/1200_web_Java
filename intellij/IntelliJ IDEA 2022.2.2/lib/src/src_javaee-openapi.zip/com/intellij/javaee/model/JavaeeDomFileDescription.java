/*
 * Copyright (c) 2000-2006 JetBrains s.r.o. All Rights Reserved.
 */
package com.intellij.javaee.model;

import com.intellij.javaee.model.xml.JavaeeDomModelElement;
import com.intellij.util.xml.DomFileDescription;
import org.jetbrains.annotations.NonNls;

/**
 * @author peter
 */
public abstract class JavaeeDomFileDescription<T extends JavaeeDomModelElement> extends DomFileDescription<T> {

  public JavaeeDomFileDescription(final Class<T> rootElementClass, @NonNls final String rootTagName) {
    super(rootElementClass, rootTagName);
  }

  @Override
  public boolean isAutomaticHighlightingEnabled() {
    return false;
  }
}

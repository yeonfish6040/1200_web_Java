package com.intellij.javaee.utils.persistence.data.nodes;

import com.intellij.openapi.util.text.StringUtil;
import com.intellij.util.Function;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public abstract class ContainerNode extends QueryNode {

    private final Set<QueryNode> children = new LinkedHashSet<>();

    public ContainerNode(@NotNull String expression) {
        super(expression);

        final String operation = getChildrenNodesDelimiter();

        final List<String> strings = StringUtil.split(expression, operation, true, false);
        for (int i = 0; i < strings.size(); i++) {
            String s = strings.get(i);
            children.add(getChildrenFactory().fun(s));
            if (i != strings.size() - 1) {
                children.add(new SimpleLeaf(operation));
            }
        }
    }

    protected Function<String, QueryNode> getChildrenFactory() {
        return SimpleLeaf::new;
    }

    @Override
    @NotNull
    public Set<? extends QueryNode> getChildren() {
        return children;
    }

    protected String getChildrenNodesDelimiter() {
        return "";
    }

    @Override
    public String getExpression() {
        List<String> strings = ContainerUtil.map(getChildren(), queryNode -> queryNode.getExpression());
        return StringUtil.join(strings, "");
    }
}

package com.intellij.javaee.utils.persistence.data.nodes;

import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NotNull;

import java.util.HashSet;
import java.util.Set;

public class SortNode extends PropertyNode {
    private Direction myDirection = Direction.DEFAULT;
    private String myPropertyName = "";

    public SortNode(@NotNull String expression) {
        super(expression);
        for (Direction direction : Direction.ALL) {
            final String name = direction.getName();
            if (expression.endsWith(name)) {
                myDirection = direction;
                myPropertyName =
                        StringUtil.decapitalize(StringUtil.isEmpty(name) ? expression : expression.substring(0, expression.indexOf(name)));
            break;
            }
        }
    }

    public Direction getDirection() {
        return myDirection;
    }

    @Override
    public String getPropertyName() {
        return myPropertyName;
    }

    @Override
    public boolean isDefaultKeyword() {
        return myDirection == Direction.DEFAULT;
    }

    public enum Direction {
        ASC("Asc"), DESC("Desc"), DEFAULT("");

        public static Direction[] ALL = {ASC, DESC, DEFAULT};

        private final String myName;

        Direction(@NotNull String name) {
            myName = name;
        }

        public String getName() {
            return myName;
        }
    }

        @Override
        public Set<String> getPropertyKeywords() {
            final HashSet<String> strings = new HashSet<>();

            strings.add(Direction.ASC.getName());
            strings.add(Direction.DESC.getName());

            return strings;
        }

    @NotNull
    @Override
    public String getKeyword() {
        return myDirection.getName();
    }
}

package com.intellij.javaee.utils.persistence.data.inspections;

import com.intellij.util.ArrayUtil;
import org.jetbrains.annotations.NotNull;

public class TypeWrapper {
  public static final TypeWrapper UNKNOWN = new TypeWrapper("");

  public final @NotNull String repositoryClass;
  public String[] simpleTypes = ArrayUtil.EMPTY_STRING_ARRAY;
  public String[] collectionTypes = ArrayUtil.EMPTY_STRING_ARRAY;

  public static TypeWrapper create(@NotNull String aClass) { return new TypeWrapper(aClass); }

  public TypeWrapper supportedSimpleTypes(String... simple) {
    simpleTypes = simple;
    return this;
  }

  public TypeWrapper supportedCollectionTypes(String... collectionTypes) {
    this.collectionTypes = collectionTypes;
    return this;
  }

  private TypeWrapper(@NotNull String aClass) {
    repositoryClass = aClass;
  }

  public String[] getAllSupportedTypes() {
    return ArrayUtil.mergeArrays(simpleTypes, collectionTypes);
  }
}

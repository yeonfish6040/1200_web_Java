package com.intellij.javaee.utils.persistence.data.parser;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * The type of a method name part. Used to create query parts in various ways.
 *
 * @author Oliver Gierke
 * @author Thomas Darimont
 */
public abstract class PartTypes {

  public abstract List<PartType> getPartTypes();
  public abstract PartType getDefaultType();

  /**
   * Returns the {@link PartTypes} of the {@link Part} for the given raw propertyPath. This will try to detect e.g.
   * keywords contained in the raw propertyPath that trigger special query creation. Returns {@link #SIMPLE_PROPERTY}
   * by default.
   *
   * @param rawProperty
   * @return
   */
  public  PartType fromProperty(String rawProperty) {
    for (PartType type : getPartTypes()) {
      if (type.supports(rawProperty)) {
        return type;
      }
    }
    return getDefaultType();
  }

  public Collection<String> getKeywords() {
    List<String> allKeywords = new ArrayList<>();
    for (PartType type : getPartTypes()) {
      allKeywords.addAll(type.getKeywords());
    }
    return allKeywords;
  }
}

package com.intellij.javaee.utils.persistence.data.parser;

import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * The type of a method name part. Used to create query parts in various ways.
 *
 * @author Oliver Gierke
 * @author Thomas Darimont
 */
public class PartType {
  private final List<String> keywords;
  private final String myDebugName;
  private final int numberOfArguments;
  private  boolean useIgnoreCaseKeyword =false;

  /**
   * Creates a new {@link PartType} using the given keyword, number of arguments to be bound and operator. Keyword and
   * operator can be {@literal null}.
   *
   * @param numberOfArguments
   * @param keywords
   */
  private PartType(String debugName, int numberOfArguments, String... keywords) {
    this.myDebugName = debugName;
    this.numberOfArguments = numberOfArguments;
    this.keywords = Arrays.asList(keywords);
  }

  private PartType(String name, String... keywords) {
    this(name, 1, keywords);
  }

  public static PartType create(String name, int numberOfArguments, String... keywords) {
    return new PartType(name, numberOfArguments, keywords);
  }

  public static PartType create(String name, String... keywords) {
    return new PartType(name, 1, keywords);
  }
  public static PartType createIgnoreCase(String name, String... keywords) {
    return new PartType(name, 1, keywords).useIgnoreCase();
  }


  /**
   * Returns all keywords supported by the current {@link PartType}.
   *
   * @return
   */
  public Collection<String> getKeywords() {
    return Collections.unmodifiableList(keywords);
  }

  /**
   * Returns whether the the type supports the given raw property. Default implementation checks whether the property
   * ends with the registered keyword. Does not support the keyword if the property is a valid field as is.
   *
   * @param property
   * @return
   */
  protected boolean supports(String property) {
    if (keywords == null) {
      return true;
    }

    for (String keyword : keywords) {
      if (property.endsWith(keyword)) {
        return true;
      }
    }

    return false;
  }

  /**
   * Returns the number of arguments the propertyPath binds. By default this exactly one argument.
   *
   * @return
   */
  public int getNumberOfArguments() {
    return numberOfArguments;
  }

  /**
   * Callback method to extract the actual propertyPath to be bound from the given part. Strips the keyword from the
   * part's end if available.
   *
   * @param part
   * @return
   */
  @NotNull
  public String extractProperty(@NotNull String part) {
    String candidate = StringUtil.decapitalize(part);
    for (String keyword : keywords) {
      if (candidate.endsWith(keyword)) {
        return candidate.substring(0, candidate.length() - keyword.length());
      }
    }
    return candidate;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Enum#toString()
   */
  @Override
  public String toString() {
    return String.format("%s (%s): %s", name(), getNumberOfArguments(), getKeywords());
  }

  public  String name() {
    return myDebugName;
  }

  public  PartType useIgnoreCase() {
    useIgnoreCaseKeyword = true;
    return this;
  }

  public boolean isUseIgnoreCase() {
    return useIgnoreCaseKeyword;
  }
}

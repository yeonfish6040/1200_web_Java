package com.intellij.javaee.utils.persistence.data.nodes;

import org.jetbrains.annotations.NotNull;

public class SimpleLeaf extends QueryNode {

    public SimpleLeaf(@NotNull final String expression) {
        super(expression);
    }
}

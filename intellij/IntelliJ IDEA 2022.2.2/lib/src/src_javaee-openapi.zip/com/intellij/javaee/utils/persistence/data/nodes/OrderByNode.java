package com.intellij.javaee.utils.persistence.data.nodes;

import org.jetbrains.annotations.NotNull;

import java.util.LinkedHashSet;
import java.util.Set;

public class OrderByNode extends QueryNode {
    private static final String BLOCK_SPLIT = "(?<=Asc|Desc)(?=[A-Z])";
    private final Set<SortNode> myOrderNodes = new LinkedHashSet<>();

    public OrderByNode(@NotNull String expression) {
        super(expression);
        for (String orderExpression : expression.split(BLOCK_SPLIT)) {
            myOrderNodes.add(new SortNode(orderExpression));
        }
    }


    @NotNull
    @Override
    public Set<? extends QueryNode> getChildren() {
        return myOrderNodes;
    }
}

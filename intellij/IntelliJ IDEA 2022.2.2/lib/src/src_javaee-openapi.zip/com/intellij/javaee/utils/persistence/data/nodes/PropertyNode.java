package com.intellij.javaee.utils.persistence.data.nodes;

import org.jetbrains.annotations.NotNull;

import java.util.Set;

public abstract class PropertyNode extends QueryNode {

    public PropertyNode(@NotNull final String expression) {
        super(expression);
    }

    public abstract String getPropertyName() ;

    public abstract boolean isDefaultKeyword() ;

    public abstract Set<String> getPropertyKeywords();

    @NotNull
    public abstract String getKeyword();
}

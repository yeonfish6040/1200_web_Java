package com.intellij.javaee.utils.persistence.data.nodes;

import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RootNode extends ContainerNode {
    private static final Pattern ALL_IGNORE_CASE = Pattern.compile("AllIgnor(ing|e)Case");

    private final Set<QueryNode> nodes = new LinkedHashSet<>();
    private boolean alwaysIgnoreCase = false;

    public RootNode(@NotNull String expression, String methodType) {
        super(expression);

        if (!StringUtil.isEmptyOrSpaces(methodType)) nodes.add(new SimpleLeaf(methodType));

        final List<String> orderByParts = StringUtil.split(detectAndSetAllIgnoreCase(expression), ORDER_BY, true, false);
        for (int i = 0; i < orderByParts.size(); i++) {
            final String orderBy = orderByParts.get(i);
            if (i == 0) {
                nodes.add(new OrSetNode(orderBy));
            }
            else {
                nodes.add(new OrderByNode(orderBy));
            }
            if (i != orderByParts.size()-1) {
                nodes.add(new SimpleLeaf(ORDER_BY));
            }
        }
    }

    @Override
    @NotNull
    public Set<? extends QueryNode> getChildren() {
        return nodes;
    }

    private String detectAndSetAllIgnoreCase(String expression) {
        Matcher matcher = ALL_IGNORE_CASE.matcher(expression);

        if (matcher.find()) {
            alwaysIgnoreCase = true;
            expression = expression.substring(0, matcher.start()) + expression.substring(matcher.end());
        }

        return expression;
    }
}

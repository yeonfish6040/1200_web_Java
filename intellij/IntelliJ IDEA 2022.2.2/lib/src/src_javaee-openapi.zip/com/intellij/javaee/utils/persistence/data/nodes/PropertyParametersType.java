package com.intellij.javaee.utils.persistence.data.nodes;

//org.springframework.data.xml.query.parser.Part$Type (Oliver Gierke)
public enum PropertyParametersType {

    BETWEEN(2, "IsBetween", "Between"),
    IS_NOT_NULL(0, "IsNotNull", "NotNull"),
    IS_NULL(0, "IsNull", "Null"),
    LESS_THAN("IsLessThan", "LessThan"),
    LESS_THAN_EQUAL("IsLessThanEqual", "LessThanEqual"),
    GREATER_THAN("IsGreaterThan", "GreaterThan"),
    GREATER_THAN_EQUAL("IsGreaterThanEqual", "GreaterThanEqual"),
    BEFORE("IsBefore", "Before"),
    AFTER("IsAfter", "After"),
    NOT_LIKE("IsNotLike", "NotLike"),
    LIKE("IsLike", "Like"),
    STARTING_WITH("IsStartingWith", "StartingWith", "StartsWith"),
    ENDING_WITH("IsEndingWith", "EndingWith", "EndsWith"),
    NOT_CONTAINING("IsNotContaining", "NotContaining", "NotContains"),
    CONTAINING("IsContaining", "Containing", "Contains"),
    NOT_IN("IsNotIn", "NotIn"),
    IN("IsIn", "In"),
    NEAR("IsNear", "Near"),
    WITHIN("IsWithin", "Within"),
    REGEX("MatchesRegex", "Matches", "Regex"),
    EXISTS(0, "Exists"),
    TRUE(0, "IsTrue", "True"),
    FALSE(0, "IsFalse", "False"),
    NEGATING_SIMPLE_PROPERTY("IsNot", "Not"),
    SIMPLE_PROPERTY("Is", "Equals");

    // Need to list them again explicitly as the order is important
    // (esp. for IS_NULL, IS_NOT_NULL)
    public static final PropertyParametersType[] ALL = {IS_NOT_NULL, IS_NULL, BETWEEN, LESS_THAN, LESS_THAN_EQUAL, GREATER_THAN,
            GREATER_THAN_EQUAL, BEFORE, AFTER, NOT_LIKE, LIKE, STARTING_WITH, ENDING_WITH, NOT_CONTAINING, CONTAINING, NOT_IN, IN, NEAR,
            WITHIN, REGEX, EXISTS, TRUE, FALSE, NEGATING_SIMPLE_PROPERTY, SIMPLE_PROPERTY};

    private final String[] keywords;
    private final int myArgumentsNumber;

    PropertyParametersType(int argumentsNumber, String... keywords) {
        this.myArgumentsNumber = argumentsNumber;
        this.keywords = keywords;
    }

    PropertyParametersType(String... keywords) {

        this(1, keywords);
    }

    public String[] getKeywords() {
        return keywords;
    }

    public int getArgumentsNumber() {
        return myArgumentsNumber;
    }
}

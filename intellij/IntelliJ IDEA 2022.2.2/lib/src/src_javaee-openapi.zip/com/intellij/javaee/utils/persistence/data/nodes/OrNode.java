package com.intellij.javaee.utils.persistence.data.nodes;

import com.intellij.util.Function;
import org.jetbrains.annotations.NotNull;

public class OrNode extends ContainerNode {

    public OrNode(@NotNull String expression) {
        super(expression);
    }

    @Override
    protected Function<String, QueryNode> getChildrenFactory() {
        return SelectPropertyNode::new;
    }

    @Override
    protected String getChildrenNodesDelimiter() {
        return AND;
    }
}

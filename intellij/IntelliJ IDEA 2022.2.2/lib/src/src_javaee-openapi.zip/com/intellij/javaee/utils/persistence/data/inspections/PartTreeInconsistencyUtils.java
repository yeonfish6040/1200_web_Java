package com.intellij.javaee.utils.persistence.data.inspections;

import com.intellij.codeInspection.ProblemsHolder;
import com.intellij.javaee.utils.persistence.data.FrameworksDataBundle;
import com.intellij.javaee.utils.persistence.data.parser.Part;
import com.intellij.javaee.utils.persistence.data.parser.PartTree;
import com.intellij.javaee.utils.persistence.data.parser.PartTreeParserUtil;
import com.intellij.javaee.utils.persistence.data.parser.domain.OrderBySource;
import com.intellij.javaee.utils.persistence.data.parser.domain.PropertyPath;
import com.intellij.javaee.utils.persistence.data.parser.domain.Sort;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Condition;
import com.intellij.openapi.util.TextRange;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.*;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.util.InheritanceUtil;
import com.intellij.psi.util.PsiTypesUtil;
import com.intellij.psi.util.PsiUtil;
import com.intellij.util.Function;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.xml.util.XmlStringUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.uast.UClass;
import org.jetbrains.uast.UElementKt;
import org.jetbrains.uast.UMethod;

import java.util.*;
import java.util.stream.Collectors;

import static com.intellij.psi.CommonClassNames.JAVA_UTIL_COLLECTION;

public final class PartTreeInconsistencyUtils {
  public static void checkParts(@NotNull ProblemsHolder holder,
                                @NotNull UMethod uMethod,
                                @NotNull PartTree partTree) {
    List<Part> parts = partTree.getParts();
    if (parts.size() == 1 && StringUtil.isEmptyOrSpaces(parts.get(0).getSource())) return;
    for (Part part : parts) {
      for (PropertyPath property : part.getProperty()) {
        PsiType type = property.getType();
        if (type == null) {
          final PsiElement psiIdentifier = UElementKt.getSourcePsiElement(uMethod.getUastAnchor());
          if (psiIdentifier != null) {
            String propertyName = property.getSegment();
            if (StringUtil.isEmptyOrSpaces(propertyName)) {
              addEmptyPropertyProblem(holder, uMethod.getName(), partTree, part, psiIdentifier);
            }
            else {
              TextRange range = getTextRange(partTree, property);
              if (range != null) {
                holder.registerProblem(psiIdentifier, range, FrameworksDataBundle.message("cannot.resolve.property", propertyName));
              }
            }
          }
        }
      }
    }
  }

  public static void checkOrderBy(@NotNull ProblemsHolder holder, @NotNull UMethod uMethod, PartTree partTree) {
    OrderBySource source = partTree.getOrderBySource();
    if (source != null) {
      PsiElement identifier = UElementKt.getSourcePsiElement(uMethod.getUastAnchor());
      if (identifier != null) {
        for (Map.Entry<Sort.Order, TextRange> entry : PartTreeParserUtil.getSortTextRanges(partTree).entrySet()) {
          Sort.Order order = entry.getKey();
          for (PropertyPath property : order.getPropertyPath()) {
            PsiType type = property.getType();
            if (type == null) {
              String propertyName = property.getSegment();
              if (StringUtil.isEmptyOrSpaces(propertyName)) {
                String msg = getEmptyPropertyMessage(uMethod.getName(), entry.getValue());
                holder.registerProblem(identifier, FrameworksDataBundle.message("empty.property.with.empty.text.range", msg));
              }
              else {
                TextRange range = getOrderByRange(partTree, property);
                if (range != null) {
                  holder.registerProblem(identifier, range,
                                         FrameworksDataBundle.message("cannot.resolve.property", propertyName));
                }
              }
            }
          }
        }
      }
    }
  }

  private static void addEmptyPropertyProblem(@NotNull ProblemsHolder holder,
                                              String methodName,
                                              PartTree partTree,
                                              Part part,
                                              PsiElement psiIdentifier) {
    if (methodName.equals(partTree.getSubject().getExpression())) return;
    Map<Part, TextRange> textRanges = PartTreeParserUtil.getPartTextRanges(partTree);
    TextRange range = textRanges.get(part);
    if (range != null) {
      if (range.getStartOffset() == range.getEndOffset()) {
        String msg = getEmptyPropertyMessage(methodName, range);
        holder.registerProblem(psiIdentifier, FrameworksDataBundle.message("empty.property.with.empty.text.range", msg));
      }
      else {
        holder.registerProblem(psiIdentifier, range, FrameworksDataBundle.message("empty.property"));
      }
    }
  }

  @NotNull
  private static String getEmptyPropertyMessage(String methodName, TextRange range) {
    return methodName.substring(0, range.getStartOffset()) +
           "<EMPTY_PROPERTY>" + methodName.substring(range.getEndOffset());
  }

  @Nullable
  private static TextRange getTextRange(@NotNull PartTree partTree, @NotNull PropertyPath property) {
    String methodName = partTree.getSource();
    String propertyName = property.getSegment();

    Map<Part, TextRange> textRanges = PartTreeParserUtil.getPartTextRanges(partTree);
    for (Map.Entry<Part, TextRange> entry : textRanges.entrySet()) {
      for (PropertyPath path : entry.getKey().getProperty()) {
        if (path.equals(property)) {
          int startOffset = methodName.indexOf(StringUtil.capitalize(propertyName), entry.getValue().getStartOffset());
          if (startOffset >= 0) {
            return TextRange.create(startOffset, startOffset + propertyName.length());
          }
        }
      }
    }
    return null;
  }

  @Nullable
  private static TextRange getOrderByRange(@NotNull PartTree partTree, @NotNull PropertyPath property) {
    String methodName = partTree.getSource();
    String propertyName = property.getSegment();

    Map<Sort.Order, TextRange> textRanges = PartTreeParserUtil.getSortTextRanges(partTree);
    for (Map.Entry<Sort.Order, TextRange> entry : textRanges.entrySet()) {
      for (PropertyPath path : entry.getKey().getPropertyPath()) {
        if (path.equals(property)) {
          int startOffset = methodName.indexOf(StringUtil.capitalize(propertyName), entry.getValue().getStartOffset());
          return TextRange.create(startOffset, startOffset + propertyName.length());
        }
      }
    }
    return null;
  }

  public static boolean hasUnresolvedPropertyPaths(@NotNull PartTree partTree) {
    for (Part part : partTree.getParts()) {
      for (PropertyPath property : part.getProperty()) {
        PsiType type = property.getType();
        if (type == null) {
          return true;
        }
      }
    }
    return false;
  }

  @NotNull
  public static List<RequiredParameterType> getRequiredParameterTypes(@NotNull Iterable<Part> parts,
                                                                      @NotNull Project project,
                                                                      @NotNull Condition<? super Part> isCollectionTypeRequired,
                                                                      @NotNull Condition<? super Part> isCollectionElementTypeRequired,
                                                                      Function<Part, AssignableParameterTypeValidator>... assignableTypeValidators) {
    List<RequiredParameterType> psiTypes = new LinkedList<>();
    for (Part part : parts) {
      PropertyPath propertyPath = part.getProperty();
      PsiType psiType = propertyPath.getLeafProperty().getType();
      if (psiType != null) {
        RequiredParameterType requiredParameterType;
        if (isCollectionTypeRequired.value(part)) {
          requiredParameterType = RequiredParameterType.collectionType(propertyPath, createTypedCollection(project, psiType));
        }
        else if (isCollectionElementTypeRequired.value(part)) {
          requiredParameterType =
            RequiredParameterType.collectionElementType(propertyPath, getCollectionOrStringElementType(project, psiType));
        }
        else {
          requiredParameterType = RequiredParameterType.simple(propertyPath, psiType);
        }
        requiredParameterType.assignableTypeValidators =
          Arrays.stream(assignableTypeValidators)
            .map(function -> function.fun(part))
            .filter(Objects::nonNull)
            .collect(Collectors.toSet());

        final int argumentsNumber = part.getType().getNumberOfArguments();
        for (int i = 0; i < argumentsNumber; i++) {
          ContainerUtil.addAllNotNull(psiTypes, requiredParameterType);
        }
      }
    }
    return psiTypes;
  }

  @NotNull
  public static PsiType createWrappedType(@NotNull Project project, @NotNull PsiType psiType, @NotNull String wrappedClass) {
    if (StringUtil.isEmptyOrSpaces(wrappedClass)) return psiType;
    final PsiClass wrapped = JavaPsiFacade.getInstance(project).findClass(wrappedClass, GlobalSearchScope.allScope(project));
    if (wrapped == null || wrapped.getTypeParameters().length != 1) return psiType;
    if (psiType instanceof PsiPrimitiveType) {
      final PsiClassType boxedType =
        ((PsiPrimitiveType)psiType).getBoxedType(PsiManager.getInstance(project), GlobalSearchScope.allScope(project));
      if (boxedType != null) {
        return JavaPsiFacade.getInstance(project).getElementFactory().createType(wrapped, boxedType);
      }
    }
    return JavaPsiFacade.getInstance(project).getElementFactory().createType(wrapped, psiType);
  }

  @Nullable
  public static PsiType createTypedCollection(@NotNull Project project, @NotNull PsiType psiType) {
    return createTypedCollection(project, psiType, JAVA_UTIL_COLLECTION);
  }

  public static PsiType createTypedCollection(@NotNull Project project, @NotNull PsiType psiType, @NotNull String collection) {
    PsiClass aClass = getCollectionClass(project, StringUtil.isEmptyOrSpaces(collection) ? JAVA_UTIL_COLLECTION : collection);
    if (aClass == null || aClass.getTypeParameters().length != 1) return null;
    if (psiType instanceof PsiPrimitiveType) {
      psiType = ((PsiPrimitiveType)psiType).getBoxedType(PsiManager.getInstance(project), GlobalSearchScope.allScope(project));
      if (psiType == null) return null;
    }
    return JavaPsiFacade.getInstance(project).getElementFactory().createType(aClass, psiType);
  }

  public static @Nullable PsiType getCollectionOrStringElementType(@NotNull Project project, @NotNull PsiType psiType) {
    GlobalSearchScope resolveScope = psiType.getResolveScope();
    if (resolveScope != null && PsiType.getJavaLangString(PsiManager.getInstance(project), resolveScope).equals(psiType)) return psiType;
    return getSubstitutedTypeParameters(psiType, JAVA_UTIL_COLLECTION);
  }

  @Nullable
  public static PsiClass getCollectionClass(Project project, @NotNull String collection) {
    return JavaPsiFacade.getInstance(project).findClass(collection, GlobalSearchScope.allScope(project));
  }

  @Nullable
  public static PsiType getSubstitutedTypeParameters(@Nullable PsiType returnType, String... classes) {
    for (String aClass : classes) {
      final PsiType psiType = PsiUtil.substituteTypeParameter(returnType, aClass, 0, false);
      if (psiType != null) return psiType;
    }
    return null;
  }

  public static String getRequiredParametersTypesToString(final List<RequiredParameterType> requiredParameterTypes,
                                                          PsiMethod psiMethod, @NotNull TypeWrapper wrapper) {
    String[] types = new String[requiredParameterTypes.size()];


    final PsiParameter[] parameters = psiMethod.getParameterList().getParameters();
    int i = 0;
    for (Map.Entry<String, PsiType> entry : getParametersMap(requiredParameterTypes, psiMethod, wrapper).entrySet()) {
      final PsiType requredType = entry.getValue();
      boolean boldType = true;

      if (i < parameters.length) {
        final PsiType parameterType = parameters[i].getType();
        if (requredType != null && parameterType.isAssignableFrom(requredType)) {
          boldType = false;
        }
      }

      String text = requredType == null
                    ? getUnresolvedTypeText()
                    : XmlStringUtil.escapeString(getPresentableText(requredType, requiredParameterTypes.get(i).assignableTypeValidators));
      types[i] = boldType ? "<b>" + text + "</b>" : text;
      i++;
    }


    return StringUtil.join(types, ", ");
  }

  @NotNull
  private static String getPresentableText(final PsiType type, final Set<AssignableParameterTypeValidator> validators) {
    if (type == null) return getUnresolvedTypeText();
    if (validators.size() > 0) {
      return StringUtil.join(ContainerUtil.map(validators, validator -> validator.getRequiredTypePresentableText(type)), "|");
    }
    return type.getPresentableText();
  }

  @NotNull
  public static Map<String, PsiType> getParametersMap(@NotNull List<RequiredParameterType> types,
                                                      @NotNull PsiMethod psiMethod,
                                                      @NotNull TypeWrapper wrapper) {
    Map<String, PsiType> paramMap = new LinkedHashMap<>();
    final PsiClassType objectClassType = getObjectClassType(psiMethod.getProject());
    for (RequiredParameterType type : types) {
      PropertyPath nodeProperty = type.propertyPath;
      PropertyPath property = nodeProperty.getLeafProperty();
      final String propertyName = StringUtil.replace(nodeProperty.toDotPath(), ".", "_");
      PsiType psiType = property.getType();
      if (psiType != null) {
        if (type.collectionType) {
            psiType = createTypedCollection(psiMethod.getProject(), psiType, wrapper.collectionTypes.length > 0 ? wrapper.collectionTypes[0] : "");
        }  else {
          if (wrapper.simpleTypes.length > 0) {
            psiType = createWrappedType(psiMethod.getProject(), psiType, wrapper.simpleTypes[0]);
          }
        }

        String paramName = getUnusedName(paramMap, propertyName);
        paramMap.put(paramName, psiType == null ? objectClassType : psiType);
      }
    }
    return paramMap;
  }

  @Nullable
  public static PsiType getPsiType(Project project, String fqn) {
    final JavaPsiFacade psiFacade = JavaPsiFacade.getInstance(project);
    final PsiClass pageableClass = psiFacade.findClass(fqn, GlobalSearchScope.allScope(project));
    return pageableClass == null ? null : PsiTypesUtil.getClassType(pageableClass);
  }

  @NotNull
  public static String getUnusedName(@NotNull Map<String, PsiType> paramMap, @NotNull String name) {
    String paramName = name;
    int i = 0;
    while (paramMap.containsKey(paramName)) {
      i++;
      paramName = name + (i + 1); // :)
    }
    return paramName;
  }

  private static PsiClassType getObjectClassType(Project project) {
    return PsiType.getJavaLangObject(PsiManager.getInstance(project), GlobalSearchScope.allScope(project));
  }

  @NotNull
  public static Map<String, PsiType> getPropertyPathParamsMap(@NotNull Iterable<Part> nodes,
                                                              @NotNull PsiMethod psiMethod,
                                                              @NotNull Condition<? super Part> isCollectionTypeRequired) {
    Map<String, PsiType> paramMap = new LinkedHashMap<>();
    final PsiClassType objectClassType = getObjectClassType(psiMethod.getProject());
    for (Part node : nodes) {
      PropertyPath nodeProperty = node.getProperty();
      PropertyPath property = nodeProperty.getLeafProperty();
      final String propertyName = StringUtil.replace(nodeProperty.toDotPath(), ".", "_");
      PsiType psiType = property.getType();
      if (psiType != null) {
        if (isCollectionTypeRequired.value(node)) {
          psiType = createTypedCollection(psiMethod.getProject(), psiType);
        }
        final int argumentsNumber = node.getType().getNumberOfArguments();
        for (int arg = 0; arg < argumentsNumber; arg++) {
          String paramName = getUnusedName(paramMap, propertyName);

          paramMap.put(paramName, psiType == null ? objectClassType : psiType);
        }
      }
    }
    return paramMap;
  }

  public interface PartTreeParametersCheckHelper {
    String[] getPossibleWrappers(boolean withReactive);

    String[] getPossibleCollections(boolean withReactive, boolean withCoroutines);

    boolean acceptReactiveTypeParameters(UClass uClass);

    boolean acceptCoroutineTypeParameters(UClass uClass);

    boolean isNotQueryParameter(@NotNull PsiMethod psiMethod, PsiType parameterType);
  }

  public static boolean areAssignableTypes(@NotNull PsiMethod psiMethod,
                                           @NotNull List<RequiredParameterType> requiredParameterTypes,
                                           @NotNull PsiClass domainClass, UClass repositoryClass,
                                           @NotNull PartTreeParametersCheckHelper helper
  ) {
    final PsiParameter[] parameters = psiMethod.getParameterList().getParameters();
    if (parameters.length == 0) return requiredParameterTypes.size() == 0;

    boolean shouldCheckReactiveTypes = helper.acceptReactiveTypeParameters(repositoryClass);
    boolean shouldCheckCoroutinesTypes = helper.acceptCoroutineTypeParameters(repositoryClass);

    int requiredParameterIndex = 0;
    for (RequiredParameterType requiredParameterType : requiredParameterTypes) {
      if (requiredParameterIndex > parameters.length - 1) return false;
      PsiParameter parameter = parameters[requiredParameterIndex];
      PsiType parameterType = parameter.getType();

      if (helper.isNotQueryParameter(psiMethod, parameterType)) continue;

      PsiType requiredType = requiredParameterType.type;
      if (requiredType == null) {
        requiredParameterIndex++;
        continue;
      }

      if (requiredParameterType.collectionType) {
        final PsiType substitutedTypeParameter =
          getSubstitutedTypeParameters(parameterType, helper.getPossibleCollections(shouldCheckReactiveTypes, shouldCheckCoroutinesTypes));
        final PsiType requiredSubstitutedType = getSubstitutedTypeParameters(requiredType, JAVA_UTIL_COLLECTION);
        if (substitutedTypeParameter != null &&
            requiredSubstitutedType != null &&
            substitutedTypeParameter.isAssignableFrom(requiredSubstitutedType)) {
          requiredParameterIndex++;
          continue;
        }
        return false;
      }
      PsiType substitutedFromWrapper = getSubstitutedTypeParameters(parameterType, helper.getPossibleWrappers(shouldCheckReactiveTypes));
      if (substitutedFromWrapper != null) {
        parameterType = substitutedFromWrapper;
      }

      if (!isAssignableOrDomainClassFrom(parameterType, requiredParameterType, domainClass)) return false;
      requiredParameterIndex++;
    }

    return true;
  }

  private static boolean isAssignableOrDomainClassFrom(@NotNull PsiType parameterType,
                                                       @NotNull RequiredParameterType requiredType,
                                                       @NotNull PsiClass domainClass) {
    if (requiredType.type == null) return true;
    for (AssignableParameterTypeValidator validator : requiredType.assignableTypeValidators) {
      if (validator.isAccepted(requiredType.type)) {
        return validator.isAssignable(parameterType);
      }
    }

    if (parameterType.isAssignableFrom(requiredType.type)) return true;
    return parameterType instanceof PsiClassType && domainClass.equals(((PsiClassType)parameterType).resolve());
  }


  public static String getUnresolvedTypeText() {
    return "? extends Object";
  }

  public abstract static class AssignableParameterTypeValidator {
    public abstract boolean isAccepted(@NotNull PsiType propertyType);

    public abstract boolean isAssignable(@NotNull PsiType parameterType);

    protected String getRequiredTypePresentableText(@NotNull PsiType psiType) { return psiType.getPresentableText(); }

    protected static boolean isAssignable(@Nullable PsiType psiType, @NotNull String baseClass) {
      return psiType instanceof PsiClassType
             && InheritanceUtil.isInheritor(((PsiClassType)psiType).resolve(), false, baseClass);
    }
  }
}

package com.intellij.javaee.utils.persistence.data.parser;

import java.util.regex.Pattern;

public interface PartTreeParserContext {

  PartTypes types();

  String keywordTemplate();

  String queryPattern();

  String countPattern();

  String existsPattern();

  String deleteUpdatePattern();

  Pattern prefixTemplate();

  default String ignoreCase() {return "";}
}

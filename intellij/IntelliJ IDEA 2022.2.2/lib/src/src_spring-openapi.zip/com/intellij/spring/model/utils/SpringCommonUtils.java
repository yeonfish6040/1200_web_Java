// Copyright 2000-2021 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.utils;

import com.intellij.codeInsight.AnnotationUtil;
import com.intellij.codeInsight.JavaLibraryModificationTracker;
import com.intellij.codeInspection.dataFlow.StringExpressionHelper;
import com.intellij.facet.FacetFinder;
import com.intellij.facet.FacetManager;
import com.intellij.facet.ProjectFacetManager;
import com.intellij.ide.fileTemplates.FileTemplate;
import com.intellij.ide.fileTemplates.FileTemplateUtil;
import com.intellij.jam.JamService;
import com.intellij.model.search.SearchContext;
import com.intellij.model.search.SearchService;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtilCore;
import com.intellij.openapi.progress.EmptyProgressIndicator;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.project.DumbService;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.roots.libraries.JarVersionDetectionUtil;
import com.intellij.openapi.util.Computable;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.io.FileUtilRt;
import com.intellij.openapi.util.text.CharFilter;
import com.intellij.patterns.uast.UCallExpressionPattern;
import com.intellij.psi.*;
import com.intellij.psi.search.*;
import com.intellij.psi.search.searches.MethodReferencesSearch;
import com.intellij.psi.util.*;
import com.intellij.psi.util.CachedValueProvider.Result;
import com.intellij.spring.SpringLibraryUtil;
import com.intellij.spring.constants.SpringAnnotationsConstants;
import com.intellij.spring.constants.SpringConstants;
import com.intellij.spring.facet.SpringFacet;
import com.intellij.spring.facet.SpringSchemaVersion;
import com.intellij.spring.model.SpringBeanPointer;
import com.intellij.spring.model.jam.JamPsiMemberSpringBean;
import com.intellij.spring.model.jam.stereotype.SpringComponent;
import com.intellij.spring.model.jam.stereotype.SpringConfiguration;
import com.intellij.spring.model.xml.BeanNameProvider;
import com.intellij.spring.model.xml.BeanTypeProvider;
import com.intellij.spring.model.xml.DomSpringBeanPointer;
import com.intellij.spring.model.xml.beans.CollectionElements;
import com.intellij.util.SmartList;
import com.intellij.util.containers.ConcurrentFactoryMap;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.uast.*;
import org.jetbrains.uast.visitor.AbstractUastVisitor;

import java.util.*;
import java.util.stream.Collectors;

public final class SpringCommonUtils {

  public static final String SPRING_DELIMITERS = ",; ";

  public static final CharFilter ourFilter = ch -> SPRING_DELIMITERS.indexOf(ch) >= 0;
  private static final Key<ParameterizedCachedValue<Boolean, Module>> IS_SPRING_CONFIGURED_KEY = Key.create("IS_SPRING_CONFIGURED_IN_MODULE");
  private static final ParameterizedCachedValueProvider<Boolean, Module> IS_SPRING_CONFIGURED_PROVIDER = new ParameterizedCachedValueProvider<Boolean, Module>() {
    @Override
    public Result<Boolean> compute(Module module) {
      return Result.create(isSpringConfigured(module),
                           ProjectRootManager.getInstance(module.getProject()),
                           FacetFinder.getInstance(module.getProject()).getAllFacetsOfTypeModificationTracker(SpringFacet.FACET_TYPE_ID));
    }

    private boolean isSpringConfigured(@NotNull Module module) {
      if (hasSpringFacet(module)) return true;
      for (Module dependent : ModuleUtilCore.getAllDependentModules(module)) {
        if (hasSpringFacet(dependent)) return true;
      }
      Set<Module> dependencies = new HashSet<>();
      ModuleUtilCore.getDependencies(module, dependencies);
      for (Module dependency : dependencies) {
        if (hasSpringFacet(dependency)) return true;
      }

      return false;
    }
  };

  private SpringCommonUtils() {
  }

  public static List<String> tokenize(@NotNull String str) {
    return tokenize(str, SPRING_DELIMITERS);
  }

  @NotNull
  public static List<String> tokenize(@NotNull String str, @NotNull String delimiters) {
    final List<String> list = new SmartList<>();
    StringTokenizer st = new StringTokenizer(str, delimiters);
    while (st.hasMoreTokens()) {
      final String token = st.nextToken().trim();
      if (!token.isEmpty()) {
        list.add(token);
      }
    }
    return list;
  }

  @NotNull
  public static List<PsiType> resolveGenerics(PsiClassType classType) {
    final PsiClassType.ClassResolveResult resolveResult = classType.resolveGenerics();
    final PsiClass psiClass = resolveResult.getElement();
    if (psiClass != null) {
      final PsiSubstitutor substitutor = resolveResult.getSubstitutor();
      List<PsiType> generics = new SmartList<>();
      for (PsiTypeParameter typeParameter : psiClass.getTypeParameters()) {
        generics.add(substitutor.substitute(typeParameter));
      }
      return generics;
    }
    return Collections.emptyList();
  }

  /**
   * @param project Current project.
   * @return Whether given project contains at least one Spring facet.
   */
  public static boolean hasSpringFacets(@NotNull final Project project) {
    return ProjectFacetManager.getInstance(project).hasFacets(SpringFacet.FACET_TYPE_ID);
  }

  /**
   * @return Whether given module has Spring facet.
   */
  public static boolean hasSpringFacet(@Nullable Module module) {
    return module != null && SpringFacet.getInstance(module) != null;
  }

  /**
   * Returns whether the given class has {@value SpringAnnotationsConstants#JAVA_SPRING_CONFIGURATION} annotation, <em>excluding</em> meta-annotations.
   *
   * @see #isConfigurationOrMeta(PsiClass)
   */
  public static boolean isConfiguration(@NotNull PsiClass psiClass) {
    return isSpringBeanCandidateClass(psiClass) &&
           AnnotationUtil.isAnnotated(psiClass, SpringAnnotationsConstants.JAVA_SPRING_CONFIGURATION, 0);
  }

  /**
   * Returns whether the given class is <em>(meta-)</em>annotated with {@value SpringAnnotationsConstants#JAVA_SPRING_CONFIGURATION}.
   *
   * @param psiClass Class to check.
   * @return {@code true} if class annotated.
   */
  public static boolean isConfigurationOrMeta(@NotNull PsiClass psiClass) {
    if (!isSpringBeanCandidateClass(psiClass)) return false;
    return JamService.getJamService(psiClass.getProject()).getJamElement(SpringConfiguration.JAM_KEY, psiClass) != null;
  }

  /**
   * @return whether the given class is annotated with {@value SpringAnnotationsConstants#COMPONENT}.
   * <p>NOTE: it doesn't consider {@value SpringAnnotationsConstants#SERVICE}, {@value SpringAnnotationsConstants#REPOSITORY} and so on</p>
   * @param psiClass Class to check.
   * @see #isStereotypeComponentOrMeta(PsiClass)
   */
  public static boolean isComponentOrMeta(@NotNull PsiClass psiClass) {
    if (!isSpringBeanCandidateClass(psiClass)) return false;
    return JamService.getJamService(psiClass.getProject())
             .getJamElement(psiClass, SpringComponent.META) != null;
  }

  /**
   * Returns whether the given class is <em>(meta-)</em>annotated with {@value SpringAnnotationsConstants#COMPONENT, SpringAnnotationsConstants#SERVICE, , SpringAnnotationsConstants#REPOSITORY}.
   *
   * @param psiClass Class to check.
   * @return {@code true} if class annotated.
   */
  public static boolean isStereotypeComponentOrMeta(@NotNull PsiClass psiClass) {
    if (!isSpringBeanCandidateClass(psiClass)) return false;
    return JamService.getJamService(psiClass.getProject())
             .getJamElement(JamPsiMemberSpringBean.PSI_MEMBER_SPRING_BEAN_JAM_KEY, psiClass) != null;
  }

  /**
   * Returns whether the given PsiClass (or its inheritors) could possibly be mapped as Spring Bean.
   *
   * @param psiClass PsiClass to check.
   * @return {@code true} if yes.
   */
  @Contract("null->false")
  public static boolean isSpringBeanCandidateClass(@Nullable PsiClass psiClass) {
    if (psiClass == null ||
        !psiClass.isValid() ||
        psiClass instanceof PsiTypeParameter ||
        psiClass.hasModifierProperty(PsiModifier.PRIVATE) ||
        psiClass.isAnnotationType() ||
        psiClass.getQualifiedName() == null ||
        PsiUtil.isLocalOrAnonymousClass(psiClass)) {
      return false;
    }
    return true;
  }

  public static PsiElement createSpringXmlConfigFile(String newName, PsiDirectory directory) throws Exception {
    final Module module = ModuleUtilCore.findModuleForPsiElement(directory);
    final FileTemplate template = getSpringXmlTemplate(module);
    @NonNls final String fileName = FileUtilRt.getExtension(newName).length() == 0 ? newName + ".xml" : newName;
    return FileTemplateUtil.createFromTemplate(template, fileName, null, directory);
  }

  public static FileTemplate getSpringXmlTemplate(final Module... modules) {
    for (Module module : modules) {
      final String version = JarVersionDetectionUtil.detectJarVersion(SpringConstants.SPRING_VERSION_CLASS, module);
      if (version != null) {
        return version.startsWith("1") ?
               SpringSchemaVersion.SPRING_1_DTD.getTemplate(module.getProject()) :
               SpringSchemaVersion.SPRING_SCHEMA.getTemplate(module.getProject());
      }
    }
    return SpringSchemaVersion.SPRING_SCHEMA.getTemplate(modules[0].getProject());
  }

  @Contract("null -> false")
  public static boolean isSpringConfigured(@Nullable Module module) {
    if (module == null) {
      return false;
    }

    return CachedValuesManager.getManager(module.getProject()).getParameterizedCachedValue(module, IS_SPRING_CONFIGURED_KEY,
                                                                                           IS_SPRING_CONFIGURED_PROVIDER, false, module);
  }

  /**
   * Returns true if the given class is a bean candidate, Spring library is present in project and
   * Spring facet in current/dependent module(s) (or at least one in Project for PsiClass located in JAR) exists.
   *
   * @param psiClass Class to check.
   * @return true if all conditions apply
   */
  @Contract("null->false")
  public static boolean isSpringBeanCandidateClassInSpringProject(@Nullable PsiClass psiClass) {
    if (psiClass == null) {
      return false;
    }

    if (!hasSpringFacets(psiClass.getProject())) {
      return false;
    }

    if (!SpringLibraryUtil.hasSpringLibrary(psiClass.getProject())) {
      return false;
    }

    if (!isSpringBeanCandidateClass(psiClass)) {
      return false;
    }

    final Module module = ModuleUtilCore.findModuleForPsiElement(psiClass);
    if (isSpringEnabledModule(module)) {
      return true;
    }

    // located in JAR
    return module == null;
  }

  public static boolean isSpringEnabledModule(@Nullable Module module) {
    return isSpringConfigured(module) || SpringModelUtils.getInstance().hasAutoConfiguredModels(module);
  }

  public static boolean isInSpringEnabledModule(@Nullable UElement uElement) {
    PsiElement psi = UElementKt.getSourcePsiElement(uElement);
    if (psi == null) return false;
    return isSpringEnabledModule(ModuleUtilCore.findModuleForPsiElement(psi));
  }

  /**
   * Intersects given scope with {@code META-INF} package scope.
   *
   * @param project Project to search in.
   * @param scope   Scope to search in.
   * @return {@code null} if {@code META-INF} package does not exist, adjusted scope otherwise.
   */
  @Nullable
  public static GlobalSearchScope getConfigFilesScope(Project project, GlobalSearchScope scope) {
    final PsiPackage metaInfPackage = JavaPsiFacade.getInstance(project).findPackage("META-INF");
    if (metaInfPackage == null) {
      return null;
    }
    final GlobalSearchScope packageScope = PackageScope.packageScope(metaInfPackage, false);
    return scope.intersectWith(packageScope);
  }

  /**
   * Finds all configuration files in {@code META-INF} package with given name in module runtime scope.
   *
   * @param module      Module to search.
   * @param withTests   Include tests scope.
   * @param filename    Config file name.
   * @param psiFileType Expected PsiFile type.
   * @param <T>         Type.
   * @return List of matching files.
   */
  public static <T extends PsiFile> List<T> findConfigFilesInMetaInf(Module module,
                                                                     boolean withTests,
                                                                     String filename,
                                                                     Class<T> psiFileType) {
    final GlobalSearchScope moduleScope = GlobalSearchScope.moduleRuntimeScope(module, withTests);
    return findConfigFilesInMetaInf(module.getProject(), moduleScope, filename, psiFileType);
  }

  /**
   * Finds all configuration files with given name in {@code META-INF} package within search scope.
   *
   * @param <T>         Type.
   * @param project     Project to search in.
   * @param scope       Search scope.
   * @param filename    Config file name
   * @param psiFileType Expected PsiFile type.
   * @return List of matching files.
   */
  @NotNull
  public static <T extends PsiFile> List<T> findConfigFilesInMetaInf(Project project,
                                                                     GlobalSearchScope scope,
                                                                     String filename,
                                                                     Class<T> psiFileType) {
    GlobalSearchScope searchScope = getConfigFilesScope(project, scope);
    if (searchScope == null) {
      return Collections.emptyList();
    }

    final PsiFile[] configFiles = FilenameIndex.getFilesByName(project, filename, searchScope);
    if (configFiles.length == 0) {
      return Collections.emptyList();
    }

    return ContainerUtil.findAll(configFiles, psiFileType);
  }

  /**
   * Returns the <em>library class</em> resolved in runtime production scope of given module, caching the result.
   *
   * @param module    Module.
   * @param className FQN of class located in libraries to find.
   * @return {@code null} if module is {@code null} or class not found.
   */
  public static PsiClass findLibraryClass(@Nullable final Module module, @NotNull final String className) {
    if (module == null || module.isDisposed()) {
      return null;
    }
    final Project project = module.getProject();
    final Map<String, PsiClass> cache =
      CachedValuesManager.getManager(project).getCachedValue(module, () -> {
        final Map<String, PsiClass> map = ConcurrentFactoryMap.createMap(
          key -> {
            return findLibraryClass(project, key, GlobalSearchScope.moduleRuntimeScope(module, false));
          }
        );
        return Result.createSingleDependency(map, JavaLibraryModificationTracker.getInstance(module.getProject()));
      });
    return cache.get(className);
  }

  @Nullable
  private static PsiClass findLibraryClass(@NotNull Project project,@NotNull String fqn, @NotNull GlobalSearchScope searchScope) {
    return DumbService.getInstance(project).runReadActionInSmartMode(() -> JavaPsiFacade.getInstance(project).findClass(fqn, searchScope));
  }

  @NotNull
  public static Set<UExpression> findParameterExpressionInMethodCalls(@NotNull PsiMethod psiMethod,
                                                                      int forParam,
                                                                      @Nullable SearchScope searchScope) {
    if (searchScope == null) return Collections.emptySet();
    return findMethodCalls(psiMethod, searchScope).stream()
      .map(uCallExpression -> uCallExpression.getArgumentForParameter(forParam))
      .filter(Objects::nonNull).collect(Collectors.toSet());
  }

  @NotNull
  private static Set<UCallExpression> findMethodCalls(@NotNull PsiMethod psiMethod,
                                                      @Nullable SearchScope searchScope,
                                                      LocalSearchScope... excludeScopes) {
    //return CachedValuesManager.getCachedValue(psiMethod, () -> {
    return MethodReferencesSearch.search(psiMethod, searchScope, true).findAll().stream().
      map(ref -> {
        return UastContextKt.getUastParentOfType(ref.getElement(), UCallExpression.class);
      }).filter(Objects::nonNull).collect(Collectors.toSet());

    //return Result.create(callExpressions, PsiModificationTracker.MODIFICATION_COUNT);
    //});
  }

  public static @NotNull List<UExpression> getReturnedUExpression(@Nullable PsiMethod method) {
    UMethod uMethod = UastContextKt.toUElement(method, UMethod.class);
    if (uMethod == null) return Collections.emptyList();
    List<UExpression> result = new SmartList<>();
    uMethod.accept(new AbstractUastVisitor() {
      @Override
      public boolean visitReturnExpression(@NotNull UReturnExpression node) {
        if (node.getJumpTarget() == uMethod) {
          ContainerUtil.addIfNotNull(result, node.getReturnExpression());
        }
        return super.visitReturnExpression(node);
      }
    });
    return result;
  }

  @Nullable
  public static String evaluateStringExpression(@Nullable UExpression expression) {
    if (expression == null) return null;
    final String evaluateString = UastUtils.evaluateString(expression);
    if (evaluateString == null) {
      // in some cases StringExpressionHelper evaluate string expressions better (for java only)
      final PsiElement sourcePsi = expression.getSourcePsi();
      if (sourcePsi instanceof PsiExpression) {
        final Pair<PsiElement, String> pair = StringExpressionHelper.evaluateExpression(sourcePsi);
        if (pair != null) return pair.second;
      }
    }
    return evaluateString;
  }

  @NotNull
  public static BeanTypeProvider getBeanTypeProvider(Class<? extends BeanTypeProvider> providerClass) {
    try {
      return providerClass.newInstance();
    }
    catch (InstantiationException | IllegalAccessException e) {
      throw new RuntimeException("Couldn't instantiate " + providerClass, e);
    }
  }

  @NotNull
  public static BeanNameProvider getBeanNameProvider(Class<? extends BeanNameProvider> providerClass) {
    try {
      return providerClass.newInstance();
    }
    catch (InstantiationException | IllegalAccessException e) {
      throw new RuntimeException("Couldn't instantiate " + providerClass, e);
    }
  }

  @NotNull
  public static Set<SpringBeanPointer<?>> filterInnerClassBeans(@NotNull Collection<SpringBeanPointer<?>> pointers) {
    return pointers.stream()
      .filter(pointer -> !isDefinedAsCollectionElement(pointer))
      .collect(Collectors.toSet());
  }

  public static boolean isDefinedAsCollectionElement(@Nullable SpringBeanPointer<?> pointer) {
    if (pointer instanceof DomSpringBeanPointer) {
      // bean is defined in collection and can't be autowired
      return (((DomSpringBeanPointer)pointer).getSpringBean()).getParent() instanceof CollectionElements;
    }
    return false;
  }

  @NotNull
  public static Collection<? extends UCallExpression> findMethodCallsByPattern(@NotNull Project project,
                                                                               @NotNull String methodName,
                                                                               @NotNull SearchScope scope,
                                                                               UCallExpressionPattern... patterns) {
    return SearchService.getInstance().searchWord(project, methodName)
      .inContexts(SearchContext.IN_CODE)
      .inScope(scope).buildQuery(occurrence -> {
        if (occurrence.getOffsetInStart() != 0) return Collections.emptySet();
        final UCallExpression uCallExpression = getUCallExpression(occurrence.getStart());
        if (uCallExpression == null) return Collections.emptySet();

        for (UCallExpressionPattern callExpressionPattern : patterns) {
          if (callExpressionPattern.accepts(uCallExpression)) {
            return Collections.singleton(uCallExpression);
          }
        }
        return Collections.emptySet();
      }).findAll();
  }

  @Nullable
  private static UCallExpression getUCallExpression(@NotNull PsiElement leafNode) {
    final UElement element = UastContextKt.toUElement(leafNode);
    if (element instanceof UCallExpression) return (UCallExpression)element;
    if (element instanceof UIdentifier) {
      final UElement uastParent = element.getUastParent();
      if (uastParent instanceof UCallExpression) return (UCallExpression)uastParent;
    }
    return null; // ??? UastContextKt.getUastParentOfType(start, UCallExpression.class);
  }

  public static <V> V withProgress(@NotNull Computable<V> callable) {
    ProgressIndicator progressIndicator = ProgressManager.getInstance().getProgressIndicator();
    if (progressIndicator != null && progressIndicator.isRunning()) {
      return callable.compute();
    }
    else {
      return ProgressManager.getInstance().runProcess(callable, new EmptyProgressIndicator());
    }
  }

  public static boolean hasXmlConfigs(@Nullable Module module) {
    if (module == null) return false;

    Collection<SpringFacet> facets = FacetManager.getInstance(module).getFacetsByType(SpringFacet.FACET_TYPE_ID);
    for (SpringFacet facet : facets) {
      if (facet.hasXmlMappings()) return true;
    }
    return false;
  }
}

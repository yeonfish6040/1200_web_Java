// Copyright 2000-2021 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.

// Generated on Thu Nov 09 17:15:14 MSK 2006
// DTD/Schema  :    http://www.springframework.org/schema/beans

package com.intellij.spring.model.xml.beans;

import com.intellij.ide.presentation.Presentation;
import com.intellij.psi.PsiFile;
import com.intellij.spring.SpringPresentationProvider;
import com.intellij.spring.model.converters.SpringImportResourceConverter;
import com.intellij.util.xml.*;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

/**
 * http://www.springframework.org/schema/beans:importElemType interface.
 */
@Presentation(icon = "com.intellij.spring.SpringApiIcons.SpringConfig", provider = SpringPresentationProvider.class)
public interface SpringImport extends DomElement {

  /**
   * Returns the value of the resource child.
   * <pre>
   * <h3>Attribute null:resource documentation</h3>
   * 	The relative resource location of the XML (bean definition) file to import,
   * 	for example "myImport.xml" or "includes/myImport.xml" or "../myImport.xml".
   * <p/>
   * </pre>
   *
   * @return the value of the resource child.
   */
  @Required
  @Convert(SpringImportResourceConverter.class)
  @Stubbed
  @NotNull GenericAttributeValue<Set<PsiFile>> getResource();
}

// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam.testContexts.jdbc;

import com.intellij.jam.JamBaseElement;
import com.intellij.jam.JamStringAttributeElement;
import com.intellij.jam.reflect.JamAnnotationMeta;
import com.intellij.jam.reflect.JamAttributeMeta;
import com.intellij.jam.reflect.JamClassMeta;
import com.intellij.jam.reflect.JamStringAttributeMeta;
import com.intellij.psi.PsiAnnotation;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElementRef;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.spring.constants.SpringAnnotationsConstants;
import com.intellij.spring.model.SpringBeanPointer;
import com.intellij.spring.model.jam.converters.SpringBeanReferenceJamConverter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

import static com.intellij.spring.constants.SpringConstants.JAVAX_SQL_DATA_SOURCE;

public class SpringTestingSqlConfig extends JamBaseElement<PsiClass> {
  public static final JamClassMeta<SpringTestingSqlConfig> META = new JamClassMeta<>(SpringTestingSqlConfig.class);
  public static final JamAnnotationMeta ANNO_META = new JamAnnotationMeta(SpringAnnotationsConstants.TEST_SQL_CONFIG);

  private static final JamStringAttributeMeta.Single<SpringBeanPointer<?>> TRANSACTION_MANAGER_ATTR_META =
    JamAttributeMeta
      .singleString("transactionManager", new SpringBeanReferenceJamConverter(SpringAnnotationsConstants.PLATFORM_TRANSACTION_MANAGER));

  private static final JamStringAttributeMeta.Single<SpringBeanPointer<?>> DATASOURCE_ATTR_META =
    JamAttributeMeta.singleString("dataSource", new SpringBeanReferenceJamConverter(JAVAX_SQL_DATA_SOURCE));

  static {
    META.addAnnotation(ANNO_META);
    ANNO_META.addAttribute(TRANSACTION_MANAGER_ATTR_META).addAttribute(DATASOURCE_ATTR_META);
  }

  private final PsiElementRef<PsiAnnotation> myPsiAnnotation;

  @SuppressWarnings("unused") public SpringTestingSqlConfig(@NotNull PsiClass psiClass) {
    super(PsiElementRef.real(psiClass));
    myPsiAnnotation = ANNO_META.getAnnotationRef(psiClass);
  }

  @SuppressWarnings("unused")
  public SpringTestingSqlConfig(PsiAnnotation annotation) {
    super(PsiElementRef.real(Objects.requireNonNull(PsiTreeUtil.getParentOfType(annotation, PsiClass.class, true))));
    myPsiAnnotation = PsiElementRef.real(annotation);
  }

  @Nullable
  public PsiAnnotation getAnnotation() {
    return myPsiAnnotation.getPsiElement();
  }

  public JamStringAttributeElement<SpringBeanPointer<?>> getTransactionManagerElement() {
    return TRANSACTION_MANAGER_ATTR_META.getJam(myPsiAnnotation);
  }

  public JamStringAttributeElement<SpringBeanPointer<?>> getDatasourceAttrElement() {
    return DATASOURCE_ATTR_META.getJam(myPsiAnnotation);
  }
}

// Copyright 2000-2021 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring;

import com.intellij.ui.IconManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public final class SpringApiIcons {
  private static @NotNull Icon load(@NotNull String path, int cacheKey, int flags) {
    return IconManager.getInstance().loadRasterizedIcon(path, SpringApiIcons.class.getClassLoader(), cacheKey, flags);
  }
  /** 16x16 */ public static final @NotNull Icon AbtractBean = load("icons/abtractBean.svg", -1569675660, 0);
  /** 16x16 */ public static final @NotNull Icon FactoryMethodBean = load("icons/factoryMethodBean.svg", -2115933915, 0);
  /** 16x16 */ public static final @NotNull Icon FileSet = load("icons/fileSet.svg", 1104081322, 0);

  public static final class Gutter {
    /** 12x12 */ public static final @NotNull Icon FactoryMethodBean = load("icons/gutter/factoryMethodBean.svg", 1828459504, 0);
    /** 12x12 */ public static final @NotNull Icon InfrastructureBean = load("icons/gutter/infrastructureBean.svg", -1089479725, 0);
    /** 12x12 */ public static final @NotNull Icon Listener = load("icons/gutter/listener.svg", 1264019015, 0);
    /** 12x12 */ public static final @NotNull Icon ParentBeanGutter = load("icons/gutter/parentBeanGutter.svg", 2064196646, 2);
    /** 12x12 */ public static final @NotNull Icon Publisher = load("icons/gutter/publisher.svg", -156122623, 0);
    /** 12x12 */ public static final @NotNull Icon RequestMapping = load("icons/gutter/requestMapping.svg", 1848818862, 0);
    /** 12x12 */ public static final @NotNull Icon ShowAutowiredCandidates = load("icons/gutter/showAutowiredCandidates.svg", -1406413767, 0);
    /** 12x12 */ public static final @NotNull Icon ShowAutowiredDependencies = load("icons/gutter/showAutowiredDependencies.svg", -836623339, 0);
    /** 12x12 */ public static final @NotNull Icon ShowCacheable = load("icons/gutter/showCacheable.svg", 1797904825, 0);
    /** 12x12 */ public static final @NotNull Icon Spring = load("icons/gutter/spring.svg", 491833064, 0);
    /** 12x12 */ public static final @NotNull Icon SpringBean = load("icons/gutter/springBean.svg", -419941764, 0);
    /** 12x12 */ public static final @NotNull Icon SpringBeanMethod = load("icons/gutter/springBeanMethod.svg", 565249708, 0);
    /** 12x12 */ public static final @NotNull Icon SpringConfig = load("icons/gutter/springConfig.svg", 243899357, 0);
    /** 12x12 */ public static final @NotNull Icon SpringJavaBean = load("icons/gutter/springJavaBean.svg", -1750284083, 0);
    /** 12x12 */ public static final @NotNull Icon SpringProperty = load("icons/gutter/springProperty.svg", -280350962, 0);
    /** 12x12 */ public static final @NotNull Icon SpringScan = load("icons/gutter/springScan.svg", -91626889, 0);
  }

  /** 16x16 */ public static final @NotNull Icon ImplicitBean = load("icons/implicitBean.svg", 48269941, 0);
  /** 16x16 */ public static final @NotNull Icon InfrastructureBean = load("icons/infrastructureBean.svg", 600482799, 0);
  /** 16x16 */ public static final @NotNull Icon Listener = load("icons/listener.svg", -662648050, 0);
  /** 16x16 */ public static final @NotNull Icon PrototypeBean = load("icons/prototypeBean.svg", -556331492, 0);
  /** 16x16 */ public static final @NotNull Icon RequestMapping = load("icons/RequestMapping.svg", 1981438654, 0);
  /** 16x16 */ public static final @NotNull Icon ShowAutowiredDependencies = load("icons/showAutowiredDependencies.svg", -1569695384, 0);
  /** 16x16 */ public static final @NotNull Icon ShowCacheable = load("icons/showCacheable.svg", -1852605178, 0);
  /** 16x16 */ public static final @NotNull Icon Spring = load("icons/spring.svg", 1742595852, 0);
  /** 16x16 */ public static final @NotNull Icon SpringBean = load("icons/springBean.svg", 1732856675, 0);
  /** 16x16 */ public static final @NotNull Icon SpringConfig = load("icons/springConfig.svg", 1717793444, 0);
  /** 16x16 */ public static final @NotNull Icon SpringJavaBean = load("icons/springJavaBean.svg", 304558974, 0);
  /** 16x16 */ public static final @NotNull Icon SpringJavaConfig = load("icons/springJavaConfig.svg", -1000593356, 0);
  /** 16x16 */ public static final @NotNull Icon SpringProfile = load("icons/SpringProfile.svg", 995470584, 0);
  /** 16x16 */ public static final @NotNull Icon SpringProperty = load("icons/springProperty.svg", -284198597, 0);
  /** 13x13 */ public static final @NotNull Icon SpringToolWindow = load("icons/springToolWindow.svg", 1007829607, 2);
  /** 16x16 */ public static final @NotNull Icon SpringWeb = load("icons/SpringWeb.svg", 1145420881, 0);
}

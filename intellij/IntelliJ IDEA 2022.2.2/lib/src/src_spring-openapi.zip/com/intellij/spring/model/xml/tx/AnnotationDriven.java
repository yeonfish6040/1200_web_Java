// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.

// Generated on Thu Nov 09 17:15:14 MSK 2006
// DTD/Schema  :    http://www.springframework.org/schema/tx

package com.intellij.spring.model.xml.tx;

import com.intellij.spring.constants.SpringAnnotationsConstants;
import com.intellij.spring.model.SpringBeanPointer;
import com.intellij.spring.model.converters.SpringBeanResolveConverter;
import com.intellij.spring.model.xml.RequiredBeanType;
import com.intellij.util.xml.Convert;
import com.intellij.util.xml.GenericAttributeValue;
import com.intellij.util.xml.Stubbed;
import org.jetbrains.annotations.NotNull;

/**
 * @@updated: spring-tx-4.1.xsd
 */
public interface AnnotationDriven extends SpringTxElement {

  @Convert(SpringBeanResolveConverter.class)
  @RequiredBeanType(SpringAnnotationsConstants.PLATFORM_TRANSACTION_MANAGER)
  GenericAttributeValue<SpringBeanPointer<?>> getTransactionManager();

  @NotNull
  GenericAttributeValue<Mode> getMode();

  @Stubbed
  @NotNull
  GenericAttributeValue<Boolean> getProxyTargetClass();
}

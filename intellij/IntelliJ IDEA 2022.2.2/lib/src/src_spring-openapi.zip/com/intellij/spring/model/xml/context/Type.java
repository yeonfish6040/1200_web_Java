// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.

// Generated on Wed Oct 17 15:28:10 MSD 2007
// DTD/Schema  :    http://www.springframework.org/schema/context

package com.intellij.spring.model.xml.context;

import com.intellij.util.xml.NamedEnum;

/**
 * http://www.springframework.org/schema/context:typeAttrType enumeration.
 */
public enum Type implements NamedEnum {
  ANNOTATION("annotation"),
  ASPECTJ("aspectj"),
  ASSIGNABLE("assignable"),
  REGEX("regex"),
  CUSTOM("custom");

  private final String value;

  Type(String value) {
    this.value = value;
  }

  @Override
  public String getValue() {
    return value;
  }

}

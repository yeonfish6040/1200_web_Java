// Copyright 2000-2021 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.gutter.groups;

import com.intellij.icons.AllIcons;
import com.intellij.spring.SpringApiIcons;
import com.intellij.ui.LayeredIcon;
import com.intellij.ui.scale.JBUIScale;

import javax.swing.*;

public interface SpringGroupLineMarker {
  default Icon getSpringActionGroupIcon() {
    LayeredIcon icon = JBUIScale.scaleIcon(new LayeredIcon(2));
     icon.setIcon(SpringApiIcons.Gutter.SpringJavaBean, 0, 0, 0);
     icon.setIcon(AllIcons.General.DropdownGutter, 1, 0, 0);
     return icon;
   }
}

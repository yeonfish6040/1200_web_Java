// Copyright 2000-2021 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam;

import com.intellij.codeInsight.AnnotationUtil;
import com.intellij.jam.JamElement;
import com.intellij.jam.reflect.JamAnnotationMeta;
import com.intellij.jam.reflect.JamMemberMeta;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtilCore;
import com.intellij.openapi.project.DumbService;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Pair;
import com.intellij.patterns.ElementPattern;
import com.intellij.psi.PsiAnnotation;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElementRef;
import com.intellij.psi.PsiMember;
import com.intellij.psi.impl.compiled.ClsClassImpl;
import com.intellij.semantic.SemKey;
import com.intellij.semantic.SemRegistrar;
import com.intellij.semantic.SemService;
import com.intellij.spring.SpringLibraryUtil;
import com.intellij.spring.constants.SpringJavaeeConstants;
import com.intellij.spring.model.aliasFor.SpringAliasForUtils;
import com.intellij.spring.model.jam.stereotype.SpringStereotypeElement;
import com.intellij.spring.model.jam.utils.JamAnnotationTypeUtil;
import com.intellij.util.Consumer;
import com.intellij.util.Function;
import com.intellij.util.NotNullFunction;
import com.intellij.util.NullableFunction;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

import static com.intellij.spring.constants.SpringAnnotationsConstants.*;

public final class SpringSemContributorUtil {
  // predefined component annotations
  @NonNls
  public static final String[] DEFAULT_SPRING_COMPONENTS =
    {COMPONENT, CONTROLLER, REPOSITORY, SERVICE, JAVA_CONFIG_CONFIGURATION, JAVA_SPRING_CONFIGURATION, SpringJavaeeConstants.JAVAX_NAMED, SpringJavaeeConstants.JAKARTA_NAMED};

  public static <T extends JamElement, Psi extends PsiMember> void registerMetaComponents(@NotNull final SemService semService,
                                                                                          @NotNull SemRegistrar registrar,
                                                                                          @NotNull ElementPattern<? extends Psi> place,
                                                                                          @NotNull final SemKey<JamMemberMeta<Psi, T>> metaKey,
                                                                                          @NotNull final SemKey<T> semKey,
                                                                                          @NotNull final NullableFunction<? super Psi, ? extends JamMemberMeta<Psi, T>> metaFunction) {
    registrar.registerSemElementProvider(metaKey, place, metaFunction);

    registrar.registerSemElementProvider(semKey, place,
                                         (NullableFunction<Psi, T>)member -> {
                                           final JamMemberMeta<Psi, T> memberMeta = semService.getSemElement(metaKey, member);
                                           return memberMeta != null ? memberMeta.createJamElement(PsiElementRef.real(member)) : null;
                                         }
    );
  }

  public static <T extends JamElement, Psi extends PsiMember> void registerRepeatableMetaComponents(@NotNull final SemService semService,
                                                                                                    @NotNull SemRegistrar registrar,
                                                                                                    @NotNull ElementPattern<? extends Psi> place,
                                                                                                    @NotNull final SemKey<JamMemberMeta<Psi, T>> metaKey,
                                                                                                    @NotNull final SemKey<T> semKey,
                                                                                                    @NotNull final NullableFunction<? super Psi, ? extends Collection<JamMemberMeta<Psi, T>>> metaFunction) {
    registrar.registerRepeatableSemElementProvider(metaKey, place, metaFunction);

    registrar.registerRepeatableSemElementProvider(semKey, place,
                                                   (NullableFunction<Psi, Collection<T>>)member -> {
                                                     final List<JamMemberMeta<Psi, T>> memberMetas =
                                                       semService.getSemElements(metaKey, member);
                                                     Collection<T> metas = new HashSet<>();
                                                     for (JamMemberMeta<Psi, T> memberMeta : memberMetas) {
                                                       ContainerUtil
                                                         .addIfNotNull(metas, memberMeta.createJamElement(PsiElementRef.real(member)));
                                                     }
                                                     return metas.isEmpty() ? null : metas;
                                                   }
    );
  }

  public static <T extends JamElement, Psi extends PsiMember> NullableFunction<Psi, JamMemberMeta<Psi, T>> createFunction(@NotNull final SemKey<T> semKey,
                                                                                                                          @NotNull final Class<? extends T> jamClass,
                                                                                                                          @NotNull final Function<? super Module, ? extends Collection<String>> annotationsGetter,
                                                                                                                          @NotNull final Function<? super Pair<String, Psi>, ? extends T> producer,
                                                                                                                          @Nullable final Consumer<? super JamMemberMeta<Psi, T>> metaConsumer) {
    return createFunction(semKey, jamClass, annotationsGetter, producer, metaConsumer, null);
  }

  /**
   * @see SpringAliasForUtils#getAnnotationMetaProducer(SemKey, JamMemberMeta[])
   */
  public static <T extends JamElement, Psi extends PsiMember> NullableFunction<Psi, JamMemberMeta<Psi, T>> createFunction(@NotNull final SemKey<T> semKey,
                                                                                                                          @NotNull final Class<? extends T> jamClass,
                                                                                                                          @NotNull final Function<? super Module, ? extends Collection<String>> annotationsGetter,
                                                                                                                          @NotNull final Function<? super Pair<String, Psi>, ? extends T> producer,
                                                                                                                          @Nullable final Consumer<? super JamMemberMeta<Psi, T>> metaConsumer,
                                                                                                                          @Nullable final NotNullFunction<? super Pair<String, Project>, ? extends JamAnnotationMeta> annotationMeta) {
    return psiMember -> {
      Project project = psiMember.getProject();
      if (DumbService.isDumb(project)) return null;
      if (psiMember instanceof PsiClass && ((PsiClass)psiMember).isAnnotationType()) return null;
      if (!SpringLibraryUtil.hasSpringLibrary(project)) return null;

      Module module = ModuleUtilCore.findModuleForPsiElement(psiMember);
      if (module != null && !SpringLibraryUtil.hasSpringLibrary(module)) return null;
      for (String anno : annotationsGetter.fun(module)) {
        if (AnnotationUtil.isAnnotated(psiMember, anno, AnnotationUtil.CHECK_HIERARCHY)) {
          return getMeta(semKey, producer, metaConsumer, annotationMeta, psiMember, anno);
        }
      }
      if (psiMember instanceof ClsClassImpl) {
        return getMetaForLibraryClass(semKey, annotationsGetter, producer, metaConsumer, annotationMeta, psiMember);
      }

      return null;
    };
  }

  @Nullable
  private static <T extends JamElement, Psi extends PsiMember> JamMemberMeta<Psi, T> getMetaForLibraryClass(@NotNull SemKey<T> semKey,
                                                                                                            @NotNull Function<? super Module, ? extends Collection<String>> annotationsGetter,
                                                                                                            @NotNull Function<? super Pair<String, Psi>, ? extends T> producer,
                                                                                                            @Nullable Consumer<? super JamMemberMeta<Psi, T>> metaConsumer,
                                                                                                            @Nullable NotNullFunction<? super Pair<String, Project>, ? extends JamAnnotationMeta> annotationMeta,
                                                                                                            @NotNull Psi aClass) {
    if (aClass instanceof ClsClassImpl && annotationsGetter instanceof CustomRootAnnotationsProvider) {
      for (PsiAnnotation psiAnnotation : aClass.getAnnotations()) {
        final String qualifiedName = psiAnnotation.getQualifiedName();
        if (qualifiedName == null || isFrameworkAnnotation(qualifiedName)) continue;

        final PsiClass annotationType = psiAnnotation.resolveAnnotationType();
        if (annotationType != null) {
          // performance issue: only check first-level custom annotations (annotated @Component/@Service/@ComponentScan)
          for (String rootAnnotation : ((CustomRootAnnotationsProvider)annotationsGetter).getRootAnnotations()) {
            if (annotationType.hasAnnotation(rootAnnotation)) {
              return getMeta(semKey, producer, metaConsumer, annotationMeta, aClass, qualifiedName);
            }
          }
        }
      }
    }
    return null;
  }

  private static boolean isFrameworkAnnotation(@NotNull String qualifiedName) {
    return qualifiedName.startsWith("org.springframework") ||
           qualifiedName.startsWith("javax") ||
           qualifiedName.startsWith("jakarta") ||
           qualifiedName.startsWith("java.lang") ||
           qualifiedName.startsWith("org.jetbrains");
  }

  public static <T extends JamElement, Psi extends
    PsiMember> NullableFunction<Psi, Collection<JamMemberMeta<Psi, T>>> createRepeatableFunction(
    @NotNull final SemKey<T> semKey,
    @NotNull final Function<? super Module, ? extends Collection<String>> annotationsGetter,
    @NotNull final Function<? super Pair<String, Psi>, ? extends T> producer,
    @Nullable final Consumer<? super JamMemberMeta<Psi, T>> metaConsumer,
    @Nullable final NotNullFunction<? super Pair<String, Project>, ? extends JamAnnotationMeta> annotationMeta) {
    return psiMember -> {
      Project project = psiMember.getProject();
      if (DumbService.isDumb(project)) return null;
      if (psiMember instanceof PsiClass && ((PsiClass)psiMember).isAnnotationType()) return null;
      if (!SpringLibraryUtil.hasSpringLibrary(project)) return null;

      Module module = ModuleUtilCore.findModuleForPsiElement(psiMember);
      if (module != null && !SpringLibraryUtil.hasSpringLibrary(module)) return null;

      Collection<JamMemberMeta<Psi, T>> metas = new HashSet<>();
      for (final String anno : annotationsGetter.fun(module)) {
        if (AnnotationUtil.isAnnotated(psiMember, anno, AnnotationUtil.CHECK_HIERARCHY)) {
          final JamMemberMeta<Psi, T> meta = getMeta(semKey, producer, metaConsumer, annotationMeta, psiMember, anno);

          metas.add(meta);
        }
      }
      return metas.isEmpty() ? null : metas;
    };
  }

  @NotNull
  private static <T extends JamElement, Psi extends PsiMember> JamMemberMeta<Psi, T> getMeta(@NotNull SemKey<T> semKey,
                                                                                             @NotNull Function<? super Pair<String, Psi>, ? extends T> producer,
                                                                                             @Nullable Consumer<? super JamMemberMeta<Psi, T>> metaConsumer,
                                                                                             @Nullable NotNullFunction<? super Pair<String, Project>, ? extends JamAnnotationMeta> annotationMeta,
                                                                                             Psi psiMember, String anno) {
    JamMemberMeta<Psi, T> meta = new JamMemberMeta<>(null, semKey,
                                                     ref -> producer.fun(Pair.create(anno, ref.getPsiElement())));
    if (metaConsumer != null) {
      metaConsumer.consume(meta);
    }
    if (annotationMeta != null) registerCustomAnnotationMeta(anno, meta, annotationMeta, psiMember.getProject());
    return meta;
  }

  private static <T extends JamElement, Psi extends PsiMember> void registerCustomAnnotationMeta(@NotNull String anno,
                                                                                                 @NotNull JamMemberMeta<Psi, T> meta,
                                                                                                 @NotNull NotNullFunction<? super Pair<String, Project>, ? extends JamAnnotationMeta> metaNotNullFunction,
                                                                                                 @NotNull Project project) {
    List<JamAnnotationMeta> annotations = meta.getAnnotations();
    for (JamAnnotationMeta annotationMeta : annotations) {
      if (anno.equals(annotationMeta.getAnnoName())) return;
    }
    meta.addAnnotation(metaNotNullFunction.fun(Pair.create(anno, project)));
  }

  /**
   * @param <T>
   * @return Consumer.
   * @see SpringStereotypeElement#addPomTargetProducer(JamMemberMeta)
   */
  public static <T extends SpringStereotypeElement, Psi extends
    PsiMember> Consumer<JamMemberMeta<Psi, T>> createStereotypeConsumer() {
    return SpringStereotypeElement::addPomTargetProducer;
  }

  /**
   * @param anno Annotation FQN.
   * @return Custom annotation types.
   */
  public static Function<Module, Collection<String>> getCustomMetaAnnotations(@NotNull final String anno) {
    return getCustomMetaAnnotations(anno, false);
  }

  /**
   * Returns all custom meta annotations in defined scope.
   *
   * @param anno      Annotation FQN.
   * @param withTests Whether to include annotations located in test scope.
   * @return Custom annotation types.
   */
  public static Function<Module, Collection<String>> getCustomMetaAnnotations(@NotNull final String anno, final boolean withTests) {
    return getCustomMetaAnnotations(anno, withTests, true);
  }

  /**
   * Returns all custom meta annotations in defined scope, optionally filtering custom JAM implementations.
   *
   * @param anno                           Annotation FQN.
   * @param withTests                      Whether to include annotations located in test scope.
   * @param filterCustomJamImplementations Whether to filter custom JAM implementations.
   * @return Custom annotation types.
   * @see JamCustomImplementationBean
   */
  public static Function<Module, Collection<String>> getCustomMetaAnnotations(@NotNull final String anno,
                                                                              final boolean withTests,
                                                                              final boolean filterCustomJamImplementations) {
    return new CustomMetaAnnotationsFunction(anno, filterCustomJamImplementations, withTests);
  }

  public interface CustomRootAnnotationsProvider {
    String[] getRootAnnotations();
  }

  public static class UserDefinedCustomAnnotationFunction implements Function<Module, Collection<String>>, CustomRootAnnotationsProvider {
    @Override
    public Collection<String> fun(Module module) {
      return module == null ? Collections.emptySet() : JamAnnotationTypeUtil.getInstance(module).getUserDefinedCustomComponentAnnotations();
    }

    @Override
    public String[] getRootAnnotations() { return DEFAULT_SPRING_COMPONENTS; }
  }

  public static class CustomMetaAnnotationsFunction implements Function<Module, Collection<String>>, CustomRootAnnotationsProvider {
    private final @NotNull String myRootAnnotation;
    private final boolean myFilterCustomJamImplementations;
    private final boolean myWithTests;

    public CustomMetaAnnotationsFunction(@NotNull String anno, boolean filterCustomJamImplementations, boolean withTests) {
      myRootAnnotation = anno;
      myFilterCustomJamImplementations = filterCustomJamImplementations;
      myWithTests = withTests;
    }

    @Override
    public Collection<String> fun(final Module module) {
      if (module == null) return Collections.emptySet();

      Collection<PsiClass> psiClasses = getAnnotationTypes(module, myRootAnnotation);

      final Set<String> customMetaFQNs = getJamCustomFQNs(module);

      return ContainerUtil.mapNotNull(psiClasses, psiClass -> {
        String qualifiedName = psiClass.getQualifiedName();
        if (myRootAnnotation.equals(qualifiedName)) return null;

        if (customMetaFQNs.contains(qualifiedName)) {
          return null;
        }
        return qualifiedName;
      });
    }

    @NotNull
    private Set<String> getJamCustomFQNs(Module module) {
      if (!myFilterCustomJamImplementations) {
        return Collections.emptySet();
      }

      final Set<String> customMetaFQNs = new HashSet<>();
      for (JamCustomImplementationBean bean : JamCustomImplementationBean.EP_NAME.getExtensionList()) {
        if (myRootAnnotation.equals(bean.baseAnnotationFqn)) {

          final String customMetaAnnotationFqn = bean.customMetaAnnotationFqn;
          customMetaFQNs.add(customMetaAnnotationFqn);

          Collection<PsiClass> customMetaClasses = getAnnotationTypes(module, customMetaAnnotationFqn);
          for (PsiClass customMetaClass : customMetaClasses) {
            ContainerUtil.addIfNotNull(customMetaFQNs, customMetaClass.getQualifiedName());
          }
        }
      }
      return customMetaFQNs;
    }

    private Collection<PsiClass> getAnnotationTypes(Module module, String anno) {
      if (!SpringLibraryUtil.hasSpringLibrary(module)) return Collections.emptyList();

      return myWithTests ?
             JamAnnotationTypeUtil.getInstance(module).getAnnotationTypesWithChildrenIncludingTests(anno) :
             JamAnnotationTypeUtil.getInstance(module).getAnnotationTypesWithChildren(anno);
    }

    @Override
    public String[] getRootAnnotations() {
      return new String[]{myRootAnnotation};
    }
  }
}

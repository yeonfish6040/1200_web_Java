// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam.stereotype;

import com.intellij.openapi.module.Module;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElementRef;
import com.intellij.spring.model.jam.utils.JamAnnotationTypeUtil;
import com.intellij.util.NullableFunction;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;

public abstract class SpringMetaStereotypeComponent extends SpringStereotypeElement {
  private static final NullableFunction<PsiClass, String> PSI_CLASS_FQN = PsiClass::getQualifiedName;

  @Nullable private final String myAnno;

  public SpringMetaStereotypeComponent(@Nullable String anno, @NotNull PsiClass psiClass) {
    super(anno, PsiElementRef.real(psiClass));
    myAnno = anno;
  }

  /**
   * Defining annotation class.
   */
  @Nullable
  public String getDefiningAnnotation() {
    return myAnno;
  }

  protected static Collection<String> getAnnotations(@Nullable Module module,
                                                     @NotNull String annotation) {
    if (module == null || module.isDisposed()) {
      return Collections.singleton(annotation);
    }

    final Collection<PsiClass> classes = JamAnnotationTypeUtil.getInstance(module).getAnnotationTypesWithChildrenIncludingTests(annotation);
    return ContainerUtil.mapNotNull(classes, PSI_CLASS_FQN);
  }
}
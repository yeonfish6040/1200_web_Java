package com.intellij.spring.model.values;

import com.intellij.codeInsight.lookup.LookupElement;
import com.intellij.openapi.extensions.ExtensionPointName;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiReference;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public interface SpringPlaceholderReferenceResolver {
  ExtensionPointName<SpringPlaceholderReferenceResolver> EP_NAME =
    ExtensionPointName.create("com.intellij.spring.placeholderReferenceResolver");

  @NotNull Pair<List<PsiElement>, List<VirtualFile>> resolve(@NotNull PsiReference reference);

  @NotNull List<LookupElement> getVariants(@NotNull PsiReference reference);

  boolean isProperty(@NotNull PsiElement psiElement);

  @Nullable String getPropertyValue(@NotNull PsiReference reference, @NotNull PsiElement psiElement);
}

// Copyright 2000-2021 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.constants;

import org.jetbrains.annotations.NonNls;

// we don't have dependency spring -> javaee.platform,
// so we can't use com.intellij.javaee.utils.JavaeeClass (!!! and it isn't necessary in spring modules. see usages of these constants)
public interface SpringJavaeeConstants {

  @NonNls String JAVAX_INJECT = "javax.inject.Inject"; // spring 3.0 support for JSR-330
  @NonNls String JAKARTA_INJECT = "jakarta.inject.Inject"; // spring 6.0

  @NonNls String JAVAX_NAMED = "javax.inject.Named"; // spring 3.0 support for JSR-330
  @NonNls String JAKARTA_NAMED = "jakarta.inject.Named"; // spring 6.0

  @NonNls String JAVAX_INJECT_QUALIFIER = "javax.inject.Qualifier"; // spring 3.0 support for JSR-330
  // javax annotations
  @NonNls String JAVAX_MANAGED_BEAN = "javax.annotation.ManagedBean";
  @NonNls String JAKARTA_MANAGED_BEAN = "jakarta.annotation.ManagedBean";

  @NonNls String JAVAX_RESOURCE = "javax.annotation.Resource";
  @NonNls String JAKARTA_RESOURCE = "jakarta.annotation.Resource";

  @NonNls String JAVAX_TRANSACTIONAL = "javax.transaction.Transactional";
  @NonNls String JAKARTA_TRANSACTIONAL = "javax.transaction.Transactional";

  @NonNls String JAVAX_SERVLET_WEB_SERVLET = "javax.servlet.annotation.WebServlet";
  @NonNls String JAKARTA_SERVLET_WEB_SERVLET = "jakarta.servlet.annotation.WebServlet";
  @NonNls String JAVAX_RS_PATH = "javax.ws.rs.Path";
  @NonNls String JAKARTA_RS_PATH = "jakarta.ws.rs.Path";
  String[] PRIORITY_ANNOTATIONS = {"javax.annotation.Priority", "jakarta.annotation.Priority"};

  @NonNls String JAVAX_VALIDATOR_FACTORY = "javax.validation.ValidatorFactory";
  @NonNls String JAKARTA_VALIDATOR_FACTORY = "jakarta.validation.ValidatorFactory";

  //JSR-303
  @NonNls String JAVAX_CONSTRAINT_VALIDATOR = "javax.validation.ConstraintValidator";
  @NonNls String JAKARTA_CONSTRAINT_VALIDATOR = "jakarta.validation.ConstraintValidator";
}
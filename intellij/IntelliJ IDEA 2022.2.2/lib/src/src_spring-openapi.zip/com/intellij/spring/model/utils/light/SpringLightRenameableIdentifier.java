package com.intellij.spring.model.utils.light;

import com.intellij.psi.ElementManipulator;
import com.intellij.psi.ElementManipulators;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiNamedElement;
import com.intellij.psi.impl.light.LightIdentifier;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;

public class SpringLightRenameableIdentifier extends LightIdentifier {
  private final PsiElement myDeclaration;

  public static SpringLightRenameableIdentifier create(@NotNull PsiElement declaration, String name) {
    return new SpringLightRenameableIdentifier(declaration, name);
  }

  private SpringLightRenameableIdentifier(@NotNull PsiElement declaration, String name) {
    super(declaration.getManager(), name);
    myDeclaration = declaration;
  }

  @Override
  public PsiElement replace(@NotNull PsiElement newElement) throws IncorrectOperationException {
    String newName = newElement.getText();
    if (myDeclaration.isValid()) {
      ElementManipulator<PsiElement> manipulator = ElementManipulators.getManipulator(myDeclaration);
      if (manipulator != null) {
        manipulator.handleContentChange(myDeclaration, newName);
      }
      else if (myDeclaration instanceof PsiNamedElement) {
        ((PsiNamedElement)myDeclaration).setName(newName);
      }
    }

    return create(myDeclaration, newName);
  }

  @Override
  public boolean isValid() {
    return myDeclaration == null || myDeclaration.isValid();
  }
}

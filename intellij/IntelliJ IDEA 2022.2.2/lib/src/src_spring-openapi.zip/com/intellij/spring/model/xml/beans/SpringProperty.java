// Copyright 2000-2021 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.

// Generated on Thu Nov 09 17:15:14 MSK 2006
// DTD/Schema  :    http://www.springframework.org/schema/beans

package com.intellij.spring.model.xml.beans;

import com.intellij.ide.presentation.Presentation;
import com.intellij.psi.impl.beanProperties.BeanProperty;
import com.intellij.spring.constants.SpringConstants;
import com.intellij.spring.model.converters.BeanPropertyConverter;
import com.intellij.util.xml.*;

import java.util.List;

import static com.intellij.spring.constants.SpringCorePresentationConstants.SPRING_PROPERTY;

/**
 * http://www.springframework.org/schema/beans:propertyType interface.
 */
@Namespace(SpringConstants.BEANS_NAMESPACE_KEY)
@Presentation(typeName = SPRING_PROPERTY, icon = "com.intellij.spring.SpringApiIcons.SpringProperty")
public interface SpringProperty extends SpringInjection, SpringPropertyDefinition {

  /**
   * Returns the value of the name child.
   * <pre>
   * <h3>Attribute null:name documentation</h3>
   * 	The name of the property, following JavaBean naming conventions.
   * <p/>
   * </pre>
   *
   * @return the value of the name child.
   */
  @Required
  @Convert(BeanPropertyConverter.class)
  @NameValue(referencable = false)
  @Stubbed
  GenericAttributeValue<List<BeanProperty>> getName();
}

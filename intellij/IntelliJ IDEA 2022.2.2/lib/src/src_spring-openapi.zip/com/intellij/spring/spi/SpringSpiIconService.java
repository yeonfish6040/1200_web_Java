package com.intellij.spring.spi;

import com.intellij.openapi.application.ApplicationManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

public interface SpringSpiIconService {
  static SpringSpiIconService getInstance() {
    return ApplicationManager.getApplication().getService(SpringSpiIconService.class);
  }

  @NotNull Icon getFileIcon();

  @NotNull Icon getGutterIcon();
}

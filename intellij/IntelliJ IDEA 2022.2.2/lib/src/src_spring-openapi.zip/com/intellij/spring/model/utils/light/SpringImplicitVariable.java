package com.intellij.spring.model.utils.light;

import com.intellij.navigation.ItemPresentation;
import com.intellij.psi.*;
import com.intellij.psi.impl.PsiImplUtil;
import com.intellij.psi.impl.light.ImplicitVariableImpl;
import com.intellij.psi.search.SearchScope;
import com.intellij.spring.SpringApiIcons;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.util.Objects;
public class SpringImplicitVariable extends ImplicitVariableImpl implements ItemPresentation {
   protected final PsiElement myDeclaration;
   public SpringImplicitVariable(@NotNull String name, @NonNls PsiType type, @NotNull PsiElement declaration) {
    super(declaration.getManager(), SpringLightRenameableIdentifier.create(declaration, name), type, ElementManipulators.getManipulator(declaration) != null, declaration);
     myDeclaration = declaration;
   }
  @Override
  @NotNull
  public PsiElement getNavigationElement() {
    return myDeclaration;
  }

  @Override
  public PsiElement setName(@NotNull String name) throws IncorrectOperationException {
    final PsiElement element = PsiImplUtil.setName(myNameIdentifier, name);
    if (element instanceof PsiIdentifier) myNameIdentifier = (PsiIdentifier)element;
    return this;
  }
  @Override
  public ItemPresentation getPresentation() {
    return this;
  }

  @Override
  @Nullable
  public PsiFile getContainingFile() {
    if (!isValid()) throw new PsiInvalidElementAccessException(this);
    return myDeclaration != null ? myDeclaration.getContainingFile() : null;
  }

  @Override
  public String getText() {
    final PsiIdentifier identifier = getNameIdentifier();
    return getType().getPresentableText() + " " + (identifier != null ?identifier.getText() : null);
  }

  @Override
  public String getPresentableText() {
    return getName();
  }

  @Override
  @Nullable
  public Icon getIcon(boolean open) {
    return SpringApiIcons.Spring;
  }

  @Override
  public @Nullable Icon getIcon(int flags) {
    return SpringApiIcons.Spring;
  }

  @Override
  public boolean isEquivalentTo(final PsiElement another) {
    if (another == this) return true;
    if (another instanceof SpringImplicitVariable) {
      final SpringImplicitVariable implicitVariable = (SpringImplicitVariable)another;

      final String name = implicitVariable.getName();
      return name.equals(getName()) &&
               another.getManager().areElementsEquivalent(
                 implicitVariable.getDeclaration(),
                 getDeclaration()
               );
    } else {
      return getManager().areElementsEquivalent(getDeclaration(), another);
    }
  }

  @Override
  @NotNull
  public SearchScope getUseScope() {
    final PsiFile file = (myDeclaration != null ? myDeclaration:getDeclarationScope()).getContainingFile();
    return file.getUseScope();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof SpringImplicitVariable)) return false;

    SpringImplicitVariable variable = (SpringImplicitVariable)o;
    return Objects.equals(getName(), variable.getName()) &&
           Objects.equals(myDeclaration, variable.myDeclaration);
  }

  @Override
  public int hashCode() {
    return Objects.hash(getName(), myDeclaration);
  }
  public PsiElement getDeclaration() {
    return myDeclaration;
  }
}

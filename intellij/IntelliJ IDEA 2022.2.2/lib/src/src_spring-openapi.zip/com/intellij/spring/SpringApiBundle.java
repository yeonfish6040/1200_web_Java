// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring;

import com.intellij.DynamicBundle;
import com.intellij.openapi.util.NlsSafe;
import org.jetbrains.annotations.Nls;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.PropertyKey;

import java.util.function.Supplier;

public final class SpringApiBundle extends DynamicBundle {

  public static final @NlsSafe String SPRING_NAME = "Spring";

  public static @Nls String message(@NotNull @PropertyKey(resourceBundle = PATH_TO_BUNDLE) String key, Object @NotNull ... params) {
    return ourInstance.getMessage(key, params);
  }

  public static @NotNull Supplier<@Nls String> messagePointer(
    @NotNull @PropertyKey(resourceBundle = PATH_TO_BUNDLE) String key,
    Object @NotNull ... params
  ) {
    return ourInstance.getLazyMessage(key, params);
  }

  @NonNls
  private static final String PATH_TO_BUNDLE = "messages.SpringApiBundle";
  private static final SpringApiBundle ourInstance = new SpringApiBundle();

  private SpringApiBundle() {
    super(PATH_TO_BUNDLE);
  }
}
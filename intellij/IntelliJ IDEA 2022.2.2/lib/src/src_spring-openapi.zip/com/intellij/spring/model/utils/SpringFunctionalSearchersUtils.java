package com.intellij.spring.model.utils;

import com.intellij.model.search.SearchContext;
import com.intellij.model.search.SearchService;
import com.intellij.patterns.uast.UCallExpressionPattern;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiMethod;
import com.intellij.psi.search.SearchScope;
import com.intellij.psi.search.searches.MethodReferencesSearch;
import com.intellij.util.CommonProcessors;
import com.intellij.util.Processor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.uast.*;

import java.util.*;
import java.util.stream.Collectors;

public class SpringFunctionalSearchersUtils {
  @NotNull
  public static Set<UCallExpression> findMethodsCalls(PsiMethod[] psiMethods, @Nullable SearchScope scope) {
    Set<UCallExpression> calls = new HashSet<>();
    for (PsiMethod method : psiMethods) {
      calls.addAll(findMethodCalls(method, scope));
    }
    return calls;
  }

  @NotNull
  public static Set<UCallExpression> findMethodCalls(@Nullable PsiMethod psiMethod, @Nullable SearchScope scope) {
    if (psiMethod == null || scope == null) return Collections.emptySet();
    return MethodReferencesSearch.search(psiMethod, scope, false).findAll().stream()
      .map(reference -> {
        return
          UastContextKt.getUastParentOfType(reference.getElement(), UCallExpression.class);
      })
      .filter(Objects::nonNull)
      .collect(Collectors.toSet());
  }

  @NotNull
  public static Collection<? extends UCallExpression> findMethodCallsWithSearchService(@Nullable PsiMethod psiMethod,
                                                                                       @Nullable SearchScope scope) {
    if (psiMethod == null || scope == null) return Collections.emptySet();

    return SearchService.getInstance().searchWord(psiMethod.getProject(), psiMethod.getName())
      .inContexts(SearchContext.IN_CODE)
      .inScope(scope).buildQuery(occurrence -> {
        if (occurrence.getOffsetInStart() != 0) return Collections.emptySet();
        final UCallExpression uCallExpression = UastContextKt.getUastParentOfType(occurrence.getStart(), UCallExpression.class);
        return uCallExpression != null && psiMethod.equals(uCallExpression.resolve()) ?
               Collections.singleton(uCallExpression) : Collections.emptySet();
      }).findAll();
  }

  @Nullable
  public static PsiMethod findMethod(@NotNull String name, @Nullable PsiClass psiClass) {
    if (psiClass == null) return null;
    for (PsiMethod psiMethod : psiClass.findMethodsByName(name, true)) {
      if (psiMethod != null) return psiMethod;
    }
    return null;
  }

  public static PsiMethod @NotNull [] findMethods(@NotNull String name, @Nullable PsiClass psiClass) {
    if (psiClass == null) return PsiMethod.EMPTY_ARRAY;
    return psiClass.findMethodsByName(name, false);
  }

  public static UExpression getFirstInChain(@Nullable UExpression expression) {
    if (expression instanceof UCallExpression) {
      UExpression receiver = ((UCallExpression)expression).getReceiver();
      return receiver == null ? expression : getFirstInChain(receiver);
    }
    if (expression instanceof UQualifiedReferenceExpression) {
      return getFirstInChain(((UQualifiedReferenceExpression)expression).getReceiver());
    }
    return expression;
  }

  @Nullable
  public static UCallExpression findFirstCallExpressionInChain(@Nullable UExpression expression) {
    if (expression instanceof UCallExpression) {
      UExpression receiver = ((UCallExpression)expression).getReceiver();
      if (receiver == null || findFirstCallExpressionInChain(receiver) == null) return (UCallExpression)expression;
    }
    if (expression instanceof UQualifiedReferenceExpression) {
      return findFirstCallExpressionInChain(((UQualifiedReferenceExpression)expression).getSelector());
    }
    return null;
  }

  public static Collection<UCallExpression> collectCallExpressionsInChain(@Nullable UExpression expression,
                                                                          UCallExpressionPattern... patterns) {
    CommonProcessors.CollectProcessor<UCallExpression> processor = new CommonProcessors.CollectProcessor<>(new ArrayList<>());
    processCallExpressionsInChain(expression, processor, patterns);
    return processor.getResults();
  }

  @Nullable
  public static UCallExpression findFirstCallExpressionsInChain(@Nullable UExpression expression,
                                                                UCallExpressionPattern... patterns) {
    CommonProcessors.FindFirstProcessor<UCallExpression> processor = new CommonProcessors.FindFirstProcessor<>();
    processCallExpressionsInChain(expression, processor, patterns);
    return processor.getFoundValue();
  }

  public static boolean processCallExpressionsInChain(@Nullable UExpression expression,
                                                      @NotNull Processor<UCallExpression> patternProcessor,
                                                      UCallExpressionPattern... patterns) {
    if (expression instanceof UCallExpression) {
      if (!processCallExpression((UCallExpression)expression, patternProcessor, patterns)) return false;
      UExpression receiver = ((UCallExpression)expression).getReceiver();
      if (receiver != null) return processCallExpressionsInChain(receiver, patternProcessor, patterns);
    }
    if (expression instanceof UQualifiedReferenceExpression) {
      return processCallExpressionsInChain(((UQualifiedReferenceExpression)expression).getSelector(), patternProcessor, patterns);
    }
    return true;
  }

  public static boolean processCallExpression(@Nullable UCallExpression expression,
                                              @NotNull Processor<UCallExpression> processor,
                                              UCallExpressionPattern... patterns) {
    if (expression == null) return true;
    for (UCallExpressionPattern pattern : patterns) {
      if (pattern.accepts(expression) && !processor.process(expression)) return false;
    }
    return true;
  }

  @Nullable
  public static String getUExpressionText(@NotNull UExpression expression) {
    return UastUtils.evaluateString(expression);
  }
}

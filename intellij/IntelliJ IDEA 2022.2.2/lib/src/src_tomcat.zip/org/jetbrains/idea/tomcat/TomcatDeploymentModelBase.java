package org.jetbrains.idea.tomcat;

import com.intellij.javaee.appServers.deployment.DeploymentSource;
import com.intellij.javaee.oss.server.JavaeeDeploymentModel;
import com.intellij.javaee.appServers.run.configuration.CommonModel;

public abstract class TomcatDeploymentModelBase extends JavaeeDeploymentModel {

  protected TomcatDeploymentModelBase(CommonModel parentConfiguration, DeploymentSource deploymentSource) {
    super(parentConfiguration, deploymentSource);
  }

  public abstract String getContextPath();
}

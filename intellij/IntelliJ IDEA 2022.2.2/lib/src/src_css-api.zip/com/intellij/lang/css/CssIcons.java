package com.intellij.lang.css;

import com.intellij.ui.IconManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public final class CssIcons {
  private static @NotNull Icon load(@NotNull String path, int cacheKey, int flags) {
    return IconManager.getInstance().loadRasterizedIcon(path, CssIcons.class.getClassLoader(), cacheKey, flags);
  }
  /** 16x16 */ public static final @NotNull Icon Custom_property = load("icons/css/custom_property.svg", 934451732, 0);
  /** 16x16 */ public static final @NotNull Icon Property = load("icons/css/property.svg", -604069535, 0);
  /** 16x16 */ public static final @NotNull Icon PseudoClass = load("icons/css/pseudo-class.svg", 1159748609, 0);
  /** 16x16 */ public static final @NotNull Icon PseudoElement = load("icons/css/pseudo-element.svg", -1094005838, 0);
  /** 13x13 */ public static final @NotNull Icon Toolwindow = load("icons/css/toolwindow.svg", 489822672, 2);
}

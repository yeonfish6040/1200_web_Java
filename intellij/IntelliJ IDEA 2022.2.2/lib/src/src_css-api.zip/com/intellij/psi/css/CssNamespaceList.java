package com.intellij.psi.css;

public interface CssNamespaceList extends CssElement {
  CssNamespace[] getNamespaces();
}

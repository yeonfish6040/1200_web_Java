package com.intellij.psi.css.reference;

import com.intellij.psi.PsiReference;

/**
 * Marker interface (available in CSS module), to handle CDN links like <code>&lt;link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"&gt;</code>
 */
public interface CssDownloadedLibraryReference extends PsiReference {
}

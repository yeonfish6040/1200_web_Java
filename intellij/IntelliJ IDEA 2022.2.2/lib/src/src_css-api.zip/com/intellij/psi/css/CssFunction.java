package com.intellij.psi.css;

import com.intellij.model.psi.PsiExternalReferenceHost;
import com.intellij.psi.PsiElement;
import com.intellij.psi.css.descriptor.CssFunctionDescriptor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;

public interface CssFunction extends CssDescriptorOwner, CssValueOwner, PsiExternalReferenceHost {
  @NotNull
  String getName();

  @Nullable
  PsiElement getFunctionNameElement();

  @Nullable
  PsiElement getLParenthesis();

  @Nullable
  PsiElement getRParenthesis();

  @Nullable
  CssTermType getType();

  @Override
  @NotNull
  Collection<? extends CssFunctionDescriptor> getDescriptors();

  @Override
  @NotNull
  Collection<? extends CssFunctionDescriptor> getDescriptors(@NotNull PsiElement context);
}
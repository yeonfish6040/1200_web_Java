package com.intellij.psi.css;

public interface CssValueImport extends CssElement {
}

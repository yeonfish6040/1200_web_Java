package com.intellij.psi.css;

import com.intellij.navigation.NavigationItem;
import com.intellij.psi.PsiNamedElement;

public interface CssNamedElement extends CssElement, PsiNamedElement, NavigationItem {
  int getLineNumber();
}

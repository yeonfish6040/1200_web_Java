package com.intellij.psi.css;

/**
 * @deprecated {@link CssLineNames) class has been morphed into more general {@link CssBracketedList} class, use it instead.
 */
@Deprecated(forRemoval = true)
public interface CssLineNames extends CssTerm {
}

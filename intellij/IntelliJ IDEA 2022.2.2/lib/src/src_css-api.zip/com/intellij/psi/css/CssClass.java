package com.intellij.psi.css;

import com.intellij.model.psi.PsiExternalReferenceHost;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.PsiElement;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface CssClass extends CssSelectorSuffix, PsiExternalReferenceHost {

  @Nullable PsiElement getNameIdentifier();

  @NotNull
  static String kebabToCamelCase(@NotNull String name) {
    if (!StringUtil.containsChar(name, '-')) return name;

    StringBuilder result = new StringBuilder();
    boolean afterDash = false;
    for (int i = 0; i < name.length(); i++) {
      char ch = name.charAt(i);
      if (ch == '-') {
        afterDash = true;
      }
      else if (afterDash) {
        result.append(Character.toUpperCase(ch));
        afterDash = false;
      }
      else {
        result.append(ch);
      }
    }
    return result.toString();
  }
}

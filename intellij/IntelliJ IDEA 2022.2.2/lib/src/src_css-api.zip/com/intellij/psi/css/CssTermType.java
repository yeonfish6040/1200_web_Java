package com.intellij.psi.css;

public interface CssTermType {
  CssTermType UNKNOWN = new CssTermType() {
    @Override
    public String toString() {
      return "UNKNOWN_TYPE";
    }
  };

  CssTermType AS_NEEDED = new CssTermType() {
    @Override
    public String toString() {
      return "AS_NEEDED";
    }
  };
}

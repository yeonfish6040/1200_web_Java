package com.intellij.spring.boot.model;

import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.annotations.NotNull;

public interface SpringBootConfigImport {
  @NotNull VirtualFile getVirtualFile();

  int getDocumentId();
}

// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot;

public final class SpringBootClassesConstants {

  public static final String SPRING_APPLICATION = "org.springframework.boot.SpringApplication";
  public static final String SPRING_APPLICATION_BUILDER = "org.springframework.boot.builder.SpringApplicationBuilder";

  public static final String APPLICATION_ARGUMENTS = "org.springframework.boot.ApplicationArguments";

  public static final String CONFIGURATION_PROPERTIES = "org.springframework.boot.context.properties.ConfigurationProperties";
  public static final String NESTED_CONFIGURATION_PROPERTY = "org.springframework.boot.context.properties.NestedConfigurationProperty";
  public static final String ENABLE_CONFIGURATION_PROPERTIES = "org.springframework.boot.context.properties.EnableConfigurationProperties";
  public static final String CONFIGURATION_PROPERTIES_SCAN = "org.springframework.boot.context.properties.ConfigurationPropertiesScan";

  public static final String CONFIGURATION_METADATA_ANNOTATION_PROCESSOR =
    "org.springframework.boot.configurationprocessor.ConfigurationMetadataAnnotationProcessor";

  public static final String RANDOM_VALUE_PROPERTY_SOURCE = "org.springframework.boot.context.config.RandomValuePropertySource";
  public static final String RANDOM_VALUE_PROPERTY_SOURCE_SB2 = "org.springframework.boot.env.RandomValuePropertySource";

  public static final String DATA_SIZE_UNIT = "org.springframework.boot.convert.DataSizeUnit";

  public static final String REMOTE_SPRING_APPLICATION = "org.springframework.boot.devtools.RemoteSpringApplication";

  public static final String CONSTRUCTOR_BINDING = "org.springframework.boot.context.properties.ConstructorBinding";
}

// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.application.config;

import com.intellij.codeInspection.LocalQuickFix;
import com.intellij.codeInspection.ProblemHighlightType;
import com.intellij.codeInspection.ProblemsHolder;
import com.intellij.lang.properties.PropertiesBundle;
import com.intellij.microservices.jvm.config.MetaConfigKey;
import com.intellij.microservices.jvm.config.MetaConfigKey.Deprecation;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtilCore;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.PsiElement;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.search.PsiSearchHelper;
import com.intellij.psi.search.searches.ReferencesSearch;
import com.intellij.spring.boot.SpringBootApiBundle;

public class SpringBootConfigFileHighlightingUtil {
  private final ProblemsHolder myHolder;

  public SpringBootConfigFileHighlightingUtil(ProblemsHolder holder) {
    myHolder = holder;
  }

  public void highlightDeprecatedConfigKey(PsiElement keyElement,
                                           MetaConfigKey configKey,
                                           LocalQuickFix... quickFixes) {
    final Deprecation deprecation = configKey.getDeprecation();
    final String reasonShortText = deprecation.getReason().getShortText();
    String reason = StringUtil.isNotEmpty(reasonShortText)
                    ? SpringBootApiBundle.message("SpringBootConfigFileHighlightingUtil.deprecated", reasonShortText)
                    : SpringBootApiBundle
                      .message("SpringBootConfigFileHighlightingUtil.deprecated.configuration.property", configKey.getName());

    ProblemHighlightType problemHighlightType = deprecation.getLevel() == Deprecation.DeprecationLevel.ERROR
                                                ? ProblemHighlightType.GENERIC_ERROR
                                                : ProblemHighlightType.LIKE_DEPRECATED;

    myHolder.registerProblem(keyElement,
                             reason,
                             problemHighlightType,
                             quickFixes);
  }

  public void highlightUnresolvedConfigKey(PsiElement keyElement, PsiElement elementToSearch,
                                           String qualifiedConfigKeyName, boolean isOnTheFly) {
    ProgressIndicator indicator = ProgressManager.getInstance().getProgressIndicator();
    if (indicator != null) {
      if (indicator.isCanceled()) return;

      indicator.setText(PropertiesBundle.message("searching.for.property.key.progress.text", qualifiedConfigKeyName));
    }

    Module module = ModuleUtilCore.findModuleForPsiElement(keyElement);
    if (module == null) return;

    GlobalSearchScope scope = GlobalSearchScope.moduleWithDependentsScope(module);
    boolean zeroOccurrences = false;
    if (isOnTheFly) {
      PsiSearchHelper.SearchCostResult cheapEnough =
        PsiSearchHelper.getInstance(keyElement.getProject()).isCheapEnoughToSearch(qualifiedConfigKeyName, scope, null, indicator);
      if (cheapEnough == PsiSearchHelper.SearchCostResult.ZERO_OCCURRENCES) {
        zeroOccurrences = true;
      }
      else if (cheapEnough == PsiSearchHelper.SearchCostResult.TOO_MANY_OCCURRENCES) {
        return;
      }
    }

    if (zeroOccurrences ||
        ReferencesSearch.search(elementToSearch, scope, false).findFirst() == null) {
      myHolder.registerProblem(keyElement,
                               SpringBootApiBundle.message("SpringBootConfigFileHighlightingUtil.cannot.resolve.configuration.property", qualifiedConfigKeyName ),
                               ProblemHighlightType.GENERIC_ERROR_OR_WARNING);
    }
  }
}

package com.intellij.spring.boot.model;

import com.intellij.openapi.extensions.ExtensionPointName;
import com.intellij.psi.PsiFile;
import org.jetbrains.annotations.NotNull;

public interface SpringBootConfigFileDetector {
  boolean isSpringBootConfigFile(@NotNull PsiFile file);

  ExtensionPointName<SpringBootConfigFileDetector> EP_NAME = ExtensionPointName.create("com.intellij.spring.boot.configFileDetector");
}

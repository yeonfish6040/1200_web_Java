// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.model;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.extensions.ExtensionPointName;
import com.intellij.openapi.fileTypes.FileType;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.util.Condition;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiManager;
import com.intellij.psi.search.FileTypeIndex;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.search.GlobalSearchScopesCore;
import com.intellij.spring.facet.SpringFileSet;
import com.intellij.util.SmartList;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.TestOnly;
import org.jetbrains.jps.model.java.JavaResourceRootType;

import java.util.*;

/**
 * Collects all default ({@code application|bootstrap}) and/or custom named config files located in resource roots for the given filetype.
 */
public abstract class SpringBootModelConfigFileContributor {
  public static final ExtensionPointName<SpringBootModelConfigFileContributor> EP_NAME =
    ExtensionPointName.create("com.intellij.spring.boot.modelConfigFileContributor");

  private static final Comparator<VirtualFile> VF_BY_NAME_COMPARATOR = (o1, o2) -> {
    int nameCompare = StringUtil.naturalCompare(o1.getNameWithoutExtension(), o2.getNameWithoutExtension());
    if (nameCompare != 0) return nameCompare;

    // invert extension comparison, since .yml takes precedence over .yaml
    return StringUtil.compare(o2.getExtension(), o1.getExtension(), true);
  };

  private static final String SPRING_DEFAULT_PROFILE = "default";

  private static final boolean OUR_TEST_MODE = ApplicationManager.getApplication().isUnitTestMode();

  private final FileType myFileType;

  protected SpringBootModelConfigFileContributor(FileType fileType) {
    myFileType = fileType;
  }

  public FileType getFileType() {
    return myFileType;
  }

  /**
   * Returns all default and user configuration files.
   *
   * @param module           Module to evaluate.
   * @param includeTestScope
   * @return Configuration files for this contributor.
   * @deprecated Use {@link SpringBootConfigurationFileService#findConfigFiles(Module, boolean)} instead.
   */
  @Deprecated
  public List<VirtualFile> getConfigurationFiles(Module module, boolean includeTestScope) {
    List<VirtualFile> files = new SmartList<>();
    for (SpringBootModelConfigFileNameContributor fileNameContributor : SpringBootModelConfigFileNameContributor.EP_NAME.getExtensions()) {
      if (fileNameContributor.accept(module)) {
        files.addAll(getConfigurationFiles(module, fileNameContributor, includeTestScope));
      }
    }
    return files;
  }

  /**
   * Returns all default and user configuration files applicable for the given file set.
   *
   * @param module           Module to evaluate.
   * @param fileSet          Fileset to evaluate.
   * @param includeTestScope
   * @return Configuration files for this contributor.
   * @deprecated Use {@link SpringBootConfigurationFileService#findConfigFiles(Module, boolean, Condition)} instead.
   */
  @Deprecated
  public List<VirtualFile> getConfigurationFiles(Module module, SpringFileSet fileSet, boolean includeTestScope) {
    List<VirtualFile> files = new SmartList<>();
    for (SpringBootModelConfigFileNameContributor fileNameContributor : SpringBootModelConfigFileNameContributor.EP_NAME.getExtensions()) {
      if (fileNameContributor.accept(fileSet)) {
        files.addAll(getConfigurationFiles(module, fileNameContributor, includeTestScope));
        break;
      }
    }
    return files;
  }

  /**
   * @deprecated Use {@link SpringBootConfigurationFileService#findConfigFiles(Module, boolean, Condition)} instead.
   */
  @Deprecated
  public List<VirtualFile> getConfigurationFiles(Module module, SpringBootModelConfigFileNameContributor fileNameContributor,
                                                 boolean includeTestScope) {
    String springConfigName = fileNameContributor.getSpringConfigName(module);
    Pair<List<VirtualFile>, List<VirtualFile>>
      configFiles = findApplicationConfigFiles(module, includeTestScope, springConfigName);
    List<VirtualFile> customFiles = ContainerUtil.filter(fileNameContributor.findCustomConfigFiles(module),
                                                         file -> myFileType.equals(file.getFileType()));
    return ContainerUtil.concat(configFiles.first, ContainerUtil.concat(customFiles, configFiles.second));
  }

  @ApiStatus.Internal
  public Pair<List<VirtualFile>, List<VirtualFile>> findApplicationConfigFiles(Module module,
                                                                               boolean includeTestScope,
                                                                               @NotNull String baseName) {
    List<VirtualFile> profileConfigFiles = new SmartList<>();
    List<VirtualFile> baseNameConfigFiles = new SmartList<>();
    List<VirtualFile> directories = getConfigFileDirectories(module, includeTestScope);
    for (VirtualFile directory : directories) {
      Pair<List<VirtualFile>, List<VirtualFile>> allConfigs = findConfigFiles(module, directory, myFileType, baseName);
      profileConfigFiles.addAll(allConfigs.first);
      baseNameConfigFiles.addAll(allConfigs.second);
    }
    return Pair.create(profileConfigFiles, baseNameConfigFiles);
  }

  /**
   * Returns actual configuration value(s) if found in file for given profiles.
   * <p/>
   * Use {@link SpringBootConfigValueSearcher} for direct value search/processing.
   *
   * @param params Search parameters.
   * @return Actual configuration value(s) or empty list if no occurrence(s) of key.
   */
  @NotNull
  public abstract List<ConfigurationValueResult> findConfigurationValues(PsiFile configFile, ConfigurationValueSearchParams params);

  protected static boolean isProfileRelevant(@NotNull ConfigurationValueSearchParams params, @Nullable String fileNameSuffix) {
    if (fileNameSuffix == null || params.isProcessAllProfiles()) return true;
    Set<String> activeProfiles = params.getActiveProfiles();
    if (ContainerUtil.isEmpty(activeProfiles)) {
      return SPRING_DEFAULT_PROFILE.equals(fileNameSuffix);
    }
    else {
      return activeProfiles.contains(fileNameSuffix);
    }
  }

  protected static void processImports(ConfigurationValueSearchParams params, VirtualFile virtualFile,
                                       List<ConfigurationValueResult> results, int documentId) {
    if (!params.getProcessImports()) return;

    List<SpringBootConfigImport> imports =
      SpringBootConfigurationFileService.getInstance().getImports(params.getModule(), virtualFile);
    for (SpringBootConfigImport configImport : imports) {
      VirtualFile importedFile = configImport.getVirtualFile();
      if (configImport.getDocumentId() == documentId && !params.getProcessedFiles().contains(importedFile)) {
        PsiFile psiFile = PsiManager.getInstance(params.getModule().getProject()).findFile(importedFile);
        if (psiFile != null) {
          SpringBootModelConfigFileContributor contributor = getContributor(importedFile);
          if (contributor != null) {
            results.addAll(contributor.findConfigurationValues(psiFile, params));
          }
        }
      }
    }
  }

  private static boolean USE_RESOURCE_ROOTS_FOR_TESTS = false;

  @TestOnly
  public static void setUseResourceRootsForTests(boolean useResourceRootsForTests) {
    USE_RESOURCE_ROOTS_FOR_TESTS = useResourceRootsForTests;
  }

  public static @Nullable SpringBootModelConfigFileContributor getContributor(@NotNull VirtualFile virtualFile) {
    return EP_NAME.findFirstSafe(contributor -> virtualFile.getFileType().equals(contributor.getFileType()));
  }

  public static List<VirtualFile> getConfigFileDirectories(@NotNull Module module, boolean includeTestScope) {
    if (module.isDisposed()) {
      return Collections.emptyList();
    }

    ModuleRootManager moduleRootManager = ModuleRootManager.getInstance(module);

    List<VirtualFile> roots = new ArrayList<>();
    if (OUR_TEST_MODE && !USE_RESOURCE_ROOTS_FOR_TESTS) {
      ContainerUtil.addAll(roots, moduleRootManager.getContentRoots());
    }
    else {
      if (includeTestScope) {
        roots.addAll(moduleRootManager.getSourceRoots(JavaResourceRootType.TEST_RESOURCE));
      }
      roots.addAll(moduleRootManager.getSourceRoots(JavaResourceRootType.RESOURCE));
    }
    List<VirtualFile> configRoots = ContainerUtil.mapNotNull(roots, root -> {
      VirtualFile config = root.findChild("config");
      return config != null && config.isDirectory() ? config : null;
    });
    return ContainerUtil.concat(configRoots, roots);
  }

  public static Pair<List<VirtualFile>, List<VirtualFile>> findConfigFiles(@NotNull Module module,
                                                                           @NotNull VirtualFile directory,
                                                                           @NotNull FileType fileType,
                                                                           @NotNull String baseName) {
    GlobalSearchScope searchScope = GlobalSearchScopesCore.directoriesScope(module.getProject(), false, directory);
    String fileNamePrefix = baseName + '-';

    List<VirtualFile> profileConfigFiles = new SmartList<>();
    List<VirtualFile> baseNameConfigFiles = new SmartList<>();
    FileTypeIndex.processFiles(fileType, file -> {
      String fileName = file.getNameWithoutExtension();
      if (fileName.equals(baseName)) {
        baseNameConfigFiles.add(file);
      }
      else if (StringUtil.startsWith(fileName, fileNamePrefix)) {
        profileConfigFiles.add(file);
      }
      return true;
    }, searchScope);
    profileConfigFiles.sort(VF_BY_NAME_COMPARATOR);
    if (baseNameConfigFiles.size() > 1) {
      baseNameConfigFiles.sort(VF_BY_NAME_COMPARATOR);
    }
    return Pair.create(profileConfigFiles, baseNameConfigFiles);
  }
}

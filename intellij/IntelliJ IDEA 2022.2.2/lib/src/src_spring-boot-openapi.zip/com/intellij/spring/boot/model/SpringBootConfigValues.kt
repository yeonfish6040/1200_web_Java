// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.model

import com.intellij.microservices.jvm.config.MetaConfigKey
import com.intellij.microservices.jvm.config.MetaConfigKeyReference
import com.intellij.openapi.module.Module
import com.intellij.openapi.util.text.StringUtil
import com.intellij.openapi.vfs.VirtualFile
import com.intellij.psi.PsiElement
import com.intellij.util.containers.ContainerUtil

/**
 * @param configKey         Config key to search in file.
 * @param checkRelaxedNames Whether to check for relaxed names.
 * @param activeProfiles    Active profiles, {@code null} to check all files.
 * @param keyIndex          Config key's index to search in file, suitable for map and list keys.
 * @param keyProperty       Config key's property to search in file, suitable for typed map and list keys.
 * @param processImports    Whether to process imported configuration files.
 * @param processedFiles    Set of processed files. If imported file is processed, it won't be reprocessed.
 */
data class ConfigurationValueSearchParams(val module: Module,
                                          val checkRelaxedNames: Boolean = true,
                                          val activeProfiles: Set<String>?,
                                          val configKey: MetaConfigKey,
                                          val keyIndex: String?,
                                          val keyProperty: String?,
                                          val processImports: Boolean = true,
                                          val processedFiles: MutableSet<VirtualFile> = HashSet()) {

  /**
   * @param configKey         Config key to search in file.
   * @param checkRelaxedNames Whether to check for relaxed names.
   * @param activeProfiles    Active profiles, {@code null} to check all files.
   */
  constructor(module: Module,
              checkRelaxedNames: Boolean = true,
              activeProfiles: Set<String>?,
              configKey: MetaConfigKey) :
    this(module, checkRelaxedNames, activeProfiles, configKey, null, null)

  companion object {
    val PROCESS_ALL_VALUES = setOf("PROCESS_ALL_VALUES")
  }

  /**
   * Process all values, regardless of profiles/filenames/structure. Only useful to collect all occurrences across all files.
   */
  constructor(module: Module, configKey: MetaConfigKey) :
    this(module, true, PROCESS_ALL_VALUES, configKey)

  fun isProcessAllProfiles(): Boolean {
    return activeProfiles == PROCESS_ALL_VALUES
  }

}


open class ConfigurationValueResult(val keyElement: PsiElement, val keyIndexText: String?,
                                    val valueElement: PsiElement?, val valueText: String?,
                                    val documentId: Int,
                                    val params: ConfigurationValueSearchParams) {

  /**
   * Returns corresponding meta config key reference.
   *
   * @return Reference.
   */
  open fun getMetaConfigKeyReference(): MetaConfigKeyReference<out PsiElement> {
    val metaConfigKeyReference = ContainerUtil.findInstance(keyElement.references, MetaConfigKeyReference::class.java)
    if (metaConfigKeyReference == null) {
      val refText = StringUtil.join(keyElement.references, { param -> param!!.javaClass.name }, "|")
      throw IllegalStateException("${keyElement.javaClass} - '${keyElement.text}' - ${refText}}")
    }
    return metaConfigKeyReference
  }

}

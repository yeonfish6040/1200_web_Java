// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.model.autoconfigure.jam;

import com.intellij.jam.JamBaseElement;
import com.intellij.jam.JamService;
import com.intellij.jam.reflect.*;
import com.intellij.openapi.module.Module;
import com.intellij.psi.PsiAnnotation;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElementRef;
import com.intellij.semantic.SemKey;
import com.intellij.spring.boot.model.autoconfigure.SpringBootAutoconfigureClassesConstants;
import com.intellij.spring.boot.spi.SpringBootSpiClassesListJamConverter;
import com.intellij.spring.model.jam.SpringSemContributorUtil;
import com.intellij.util.Function;
import com.intellij.util.SmartList;
import com.intellij.util.containers.ConcurrentFactoryMap;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import static com.intellij.spring.boot.model.autoconfigure.SpringBootAutoconfigureClassesConstants.ENABLE_AUTO_CONFIGURATION;

public class EnableAutoConfiguration extends JamBaseElement<PsiClass> {

  private static final JamClassAttributeMeta.Collection EXCLUDE =
    new JamClassAttributeMeta.Collection("exclude");

  private static final JamStringAttributeMeta.Collection<PsiClass> EXCLUDE_NAME =
    JamAttributeMeta.collectionString("excludeName",
                                      new SpringBootSpiClassesListJamConverter(ENABLE_AUTO_CONFIGURATION,
                                                                               SpringBootAutoconfigureClassesConstants.AUTO_CONFIGURATION));

  static final JamAnnotationArchetype EXCLUDE_ARCHETYPE =
    new JamAnnotationArchetype().addAttribute(EXCLUDE).addAttribute(EXCLUDE_NAME);

  private static final JamAnnotationMeta ANNOTATION_META =
    new JamAnnotationMeta(ENABLE_AUTO_CONFIGURATION,
                          EXCLUDE_ARCHETYPE);

  public static final SemKey<EnableAutoConfiguration> JAM_KEY =
    JamService.JAM_ELEMENT_KEY.subKey("EnableAutoConfigSemKey");

  public static final JamClassMeta<EnableAutoConfiguration> META =
    new JamClassMeta<>(null, EnableAutoConfiguration.class, JAM_KEY)
      .addAnnotation(ANNOTATION_META);

  public static final SemKey<JamMemberMeta<PsiClass, EnableAutoConfiguration>> META_KEY =
    JamService.MEMBER_META_KEY.subKey("EnableAutoConfigurationMeta");

  private final String myAnno;
  private final PsiElementRef<PsiAnnotation> myAnnotationRef;

  private static final Map<String, JamAnnotationMeta> ourJamAnnotationMetaMap =
    ConcurrentFactoryMap.createMap(key -> new JamAnnotationMeta(key, EXCLUDE_ARCHETYPE));

  @SuppressWarnings("unused")
  public EnableAutoConfiguration(@NotNull PsiClass psiClass) {
    this(ENABLE_AUTO_CONFIGURATION, psiClass);
  }

  public EnableAutoConfiguration(@Nullable String anno, @NotNull PsiClass psiClass) {
    super(PsiElementRef.real(psiClass));
    myAnno = anno;
    JamAnnotationMeta annotationMeta = ourJamAnnotationMetaMap.get(anno);
    myAnnotationRef = annotationMeta.getAnnotationRef(psiClass);
  }

  public static Function<Module, Collection<String>> getAnnotations() {
    return SpringSemContributorUtil.getCustomMetaAnnotations(ENABLE_AUTO_CONFIGURATION);
  }

  @NotNull
  public String getAnnotationFqn() {
    return myAnno;
  }

  @Nullable
  public PsiAnnotation getAnnotation() {
    return myAnnotationRef.getPsiElement();
  }

  public List<PsiClass> getExcludes() {
    List<PsiClass> allExcludes = new SmartList<>();

    allExcludes.addAll(ContainerUtil.mapNotNull(EXCLUDE.getJam(myAnnotationRef),
                                                element1 -> element1.getValue()));
    allExcludes.addAll(ContainerUtil.mapNotNull(EXCLUDE_NAME.getJam(myAnnotationRef),
                                                               element -> element.getValue()));
    return allExcludes;
  }
}

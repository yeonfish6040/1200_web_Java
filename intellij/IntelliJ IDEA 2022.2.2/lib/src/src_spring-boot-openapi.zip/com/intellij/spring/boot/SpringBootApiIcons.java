// Copyright 2000-2022 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
package com.intellij.spring.boot;

import com.intellij.ui.IconManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public final class SpringBootApiIcons {
  private static @NotNull Icon load(@NotNull String path, int cacheKey, int flags) {
    return IconManager.getInstance().loadRasterizedIcon(path, SpringBootApiIcons.class.getClassLoader(), cacheKey, flags);
  }

  public static final class Gutter {
    /** 12x12 */ public static final @NotNull Icon SpringBoot = load("icons/gutter/springBoot.svg", 248038230, 0);
  }

  /** 16x16 */ public static final @NotNull Icon SpringBoot = load("icons/SpringBoot.svg", 1888235686, 0);
  /** 16x16 */ public static final @NotNull Icon SpringBoot_Overlay = load("icons/SpringBoot_Overlay.svg", -1531170622, 0);
}

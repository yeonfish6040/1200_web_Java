package com.intellij.spring.boot.spi

import com.intellij.openapi.module.Module
import com.intellij.psi.PsiClass
import com.intellij.psi.PsiElement
import com.intellij.psi.search.GlobalSearchScope
import com.intellij.util.PairProcessor

/**
 * Provides access to {@code META-INF/spring/ *.imports} configuration files.
 */
abstract class SpringBootImportsManager {
  companion object {
    fun getInstance(module: Module): SpringBootImportsManager = module.getService(SpringBootImportsManager::class.java)
  }

  /**
   * Returns all resolved classes configured for given key.
   *
   * @param includeTests Include config files in test source roots.
   * @param key          Key to search for.
   * @return Resolved classes or empty list of none found.
   */
  abstract fun getClasses(includeTests: Boolean, key: String): List<PsiClass>

  /**
   * Process all resolved classes list values.
   *
   * @param includeTests Process config files in test source roots.
   * @param processor    Processor.
   * @param valueHint    Only process properties containing given text (class FQN) as value or `null` to process all properties.
   * @return Processing result.
   */
  abstract fun processValues(includeTests: Boolean,
                             valueHint: String?,
                             processor: PairProcessor<PsiElement, PsiClass>): Boolean

  abstract fun getAutoConfigurationClasses(includeTests: Boolean): List<PsiClass>

  abstract fun getAutoConfigurationClasses(scope: GlobalSearchScope): List<PsiClass>
}
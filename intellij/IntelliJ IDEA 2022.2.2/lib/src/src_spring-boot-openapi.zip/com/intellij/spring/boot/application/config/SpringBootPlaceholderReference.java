// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.application.config;

import com.intellij.codeInsight.completion.util.ParenthesesInsertHandler;
import com.intellij.codeInsight.highlighting.HighlightedReference;
import com.intellij.codeInsight.lookup.LookupElement;
import com.intellij.codeInsight.lookup.LookupElementBuilder;
import com.intellij.ide.projectView.impl.ProjectRootsUtil;
import com.intellij.lang.properties.IProperty;
import com.intellij.lang.properties.psi.PropertiesElementFactory;
import com.intellij.lang.properties.psi.PropertiesFile;
import com.intellij.lang.properties.psi.Property;
import com.intellij.lang.properties.psi.PropertyKeyIndex;
import com.intellij.microservices.jvm.config.ConfigPlaceholderReference;
import com.intellij.microservices.jvm.config.MetaConfigKeyReference;
import com.intellij.openapi.fileTypes.FileType;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtilCore;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.TextRange;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.*;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.spring.boot.SpringBootApiIcons;
import com.intellij.spring.boot.SpringBootClassesConstants;
import com.intellij.spring.boot.library.SpringBootLibraryUtil;
import com.intellij.spring.boot.library.SpringBootLibraryUtil.SpringBootVersion;
import com.intellij.spring.boot.model.SpringBootConfigurationFileService;
import com.intellij.spring.model.utils.SpringCommonUtils;
import com.intellij.spring.model.values.SpringPlaceholderReferenceResolver;
import com.intellij.util.ArrayUtil;
import com.intellij.util.SmartList;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * Reference for {@code ${propertyKey}} placeholder expressions in value in application.properties/yaml.
 * <p/>
 * NB: Unresolved is not an error, as can be reference to JNDI and many other environment specific sources.
 *
 * @see ConfigPlaceholderReference#PLACEHOLDER_PREFIX
 * @see ConfigPlaceholderReference#PLACEHOLDER_SUFFIX
 */
public class SpringBootPlaceholderReference extends PsiReferenceBase.Poly<PsiElement>
  implements HighlightedReference, ConfigPlaceholderReference {

  private static final String RANDOM_KEY_PREFIX = "random.";

  public SpringBootPlaceholderReference(PsiElement element, TextRange range) {
    super(element, range, false);
  }

  @Override
  public ResolveResult @NotNull [] multiResolve(boolean incompleteCode) {
    final String key = getValue();

    if (StringUtil.startsWith(key, RANDOM_KEY_PREFIX)) {
      final String after = Objects.requireNonNull(StringUtil.substringAfter(key, RANDOM_KEY_PREFIX));

      for (Random random : Random.values()) {
        final String randomValue = random.getValue();
        if (random.isSupportsParameters() && StringUtil.startsWith(after, randomValue) ||
            after.equals(randomValue)) {
          if (SpringBootLibraryUtil.isBelowVersion(getModule(), random.getMinimumVersion())) {
            continue;
          }

          final PsiClass randomClass = findRandomClass();
          return randomClass != null
                 ? PsiElementResolveResult.createResults(randomClass)
                 : PsiElementResolveResult.createResults(getElement());
        }
      }
      return ResolveResult.EMPTY_ARRAY;
    }

    final IProperty systemProperty = getSystemProperties().findPropertyByKey(key);
    if (systemProperty != null) {
      return PsiElementResolveResult.createResults(systemProperty.getPsiElement());
    }

    Set<PsiElement> additionalProperties = new HashSet<>();
    for (SpringPlaceholderReferenceResolver placeholderReferenceResolver : SpringPlaceholderReferenceResolver.EP_NAME.getExtensionList()) {
      Pair<List<PsiElement>, List<VirtualFile>> resolveResult = placeholderReferenceResolver.resolve(this);
      additionalProperties.addAll(resolveResult.first);
    }
    if (!additionalProperties.isEmpty()) {
      return PsiElementResolveResult.createResults(additionalProperties.toArray(PsiElement.EMPTY_ARRAY));
    }

    // fallback to key in any .properties file
    GlobalSearchScope contentScope = getModule().getModuleContentScope();
    Collection<Property> properties = PropertyKeyIndex.getInstance().get(key, getElement().getProject(),
                                                                         getElement().getResolveScope().uniteWith(contentScope));

    return PsiElementResolveResult.createResults(properties);
  }

  @Nullable
  private PsiClass findRandomClass() {
    return SpringCommonUtils.findLibraryClass(getModule(), getRandomClassName());
  }

  @NotNull
  private String getRandomClassName() {
    if (SpringBootLibraryUtil.isAtLeastVersion(getModule(), SpringBootVersion.VERSION_2_0_0)) {
      return SpringBootClassesConstants.RANDOM_VALUE_PROPERTY_SOURCE_SB2;
    }

    return SpringBootClassesConstants.RANDOM_VALUE_PROPERTY_SOURCE;
  }

  private Module getModule() {
    return ModuleUtilCore.findModuleForPsiElement(getElement());
  }

  @NotNull
  private PropertiesFile getSystemProperties() {
    return PropertiesElementFactory.getSystemProperties(myElement.getProject());
  }

  @Override
  public Object @NotNull [] getVariants() {
    List<LookupElement> variants = new SmartList<>();
    for (SpringPlaceholderReferenceResolver placeholderReferenceResolver : SpringPlaceholderReferenceResolver.EP_NAME.getExtensionList()) {
      variants.addAll(placeholderReferenceResolver.getVariants(this));
    }

    for (IProperty property : getSystemProperties().getProperties()) {
      final String key = property.getKey();
      if (key == null) continue;
      variants.add(LookupElementBuilder.create(property, key).withIcon(SpringBootApiIcons.SpringBoot));
    }

    PsiClass randomClass = findRandomClass();
    if (randomClass == null) {
      return ArrayUtil.toObjectArray(variants);
    }

    final Module module = getModule();
    for (Random random : Random.values()) {
      if (SpringBootLibraryUtil.isBelowVersion(module, random.getMinimumVersion())) {
        continue;
      }

      final String randomText = random.getValue();
      final String insertString = RANDOM_KEY_PREFIX + randomText;

      variants.add(LookupElementBuilder.create(randomClass, insertString).withIcon(SpringBootApiIcons.SpringBoot));
      if (random.isSupportsParameters()) {
        variants.add(LookupElementBuilder.create(randomClass, insertString)
                       .withPresentableText(RANDOM_KEY_PREFIX + randomText + "(value,[max])")
                       .withIcon(SpringBootApiIcons.SpringBoot)
                       .withInsertHandler(ParenthesesInsertHandler.WITH_PARAMETERS));
      }
    }

    return ArrayUtil.toObjectArray(variants);
  }

  public static @NotNull List<VirtualFile> findConfigFiles(@NotNull PsiReference reference, @NotNull FileType fileType) {
    Module module = ModuleUtilCore.findModuleForPsiElement(reference.getElement());
    if (module == null) return Collections.emptyList();

    if (!SpringBootLibraryUtil.hasSpringBootLibrary(module)) return Collections.emptyList();

    PsiFile containingFile = reference.getElement().getContainingFile();
    PsiFile originalFile = null;
    if (containingFile != null) {
      // in completion we need to check where the original file is located
      originalFile = containingFile.getOriginalFile();
    }

    boolean includeTestScope = originalFile != null && ProjectRootsUtil.isInTestSource(originalFile);
    List<VirtualFile> configFiles = SpringBootConfigurationFileService.getInstance().findConfigFilesWithImports(module, includeTestScope);
    return ContainerUtil.filter(configFiles, configFile -> configFile.getFileType().equals(fileType));
  }

  public static @Nullable PsiElement resolveKeyReference(@NotNull PsiElement keyElement) {
    for (PsiReference psiReference : keyElement.getReferences()) {
      if (psiReference instanceof MetaConfigKeyReference) {
        return psiReference.resolve();
      }
    }
    return null;
  }

  enum Random {
    INT("int", true, SpringBootVersion.ANY),
    LONG("long", true, SpringBootVersion.ANY),
    VALUE("value", false, SpringBootVersion.ANY),
    UUID("uuid", false, SpringBootVersion.VERSION_1_4_0);

    private final String myValue;
    private final boolean mySupportsParameters;
    private final SpringBootVersion myMinimumVersion;

    Random(String value, boolean supportsParameters, SpringBootVersion minimumVersion) {
      myValue = value;
      mySupportsParameters = supportsParameters;
      myMinimumVersion = minimumVersion;
    }

    SpringBootVersion getMinimumVersion() {
      return myMinimumVersion;
    }

    String getValue() {
      return myValue;
    }

    boolean isSupportsParameters() {
      return mySupportsParameters;
    }
  }
}

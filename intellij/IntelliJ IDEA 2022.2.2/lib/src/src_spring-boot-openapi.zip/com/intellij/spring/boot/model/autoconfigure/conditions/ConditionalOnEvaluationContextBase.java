// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.model.autoconfigure.conditions;

import com.intellij.microservices.jvm.config.MetaConfigKey;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.NotNullLazyValue;
import com.intellij.openapi.util.UserDataHolderBase;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiManager;
import com.intellij.spring.boot.model.ConfigurationValueResult;
import com.intellij.spring.boot.model.ConfigurationValueSearchParams;
import com.intellij.spring.boot.model.SpringBootConfigValueSearcher;
import com.intellij.spring.boot.model.SpringBootModelConfigFileContributor;
import com.intellij.util.Processor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Set;

public class ConditionalOnEvaluationContextBase extends UserDataHolderBase implements ConditionalOnEvaluationContext {

  @NotNull
  private final PsiClass myAutoConfigClass;

  @NotNull
  private final Module myModule;

  @Nullable
  private final Set<String> myActiveProfiles;

  private final @NotNull NotNullLazyValue<? extends List<VirtualFile>> myConfigFilesCache;

  public ConditionalOnEvaluationContextBase(@NotNull PsiClass autoConfigClass,
                                            @NotNull Module module,
                                            @Nullable Set<String> activeProfiles,
                                            @NotNull NotNullLazyValue<? extends List<VirtualFile>> configFilesCache,
                                            @Nullable ConditionalOnEvaluationContextBase sharedContext) {
    myAutoConfigClass = autoConfigClass;
    myModule = module;
    myActiveProfiles = activeProfiles;
    myConfigFilesCache = configFilesCache;

    if (sharedContext != null) {
      sharedContext.copyUserDataTo(this);
    }
  }

  @NotNull
  @Override
  public PsiClass getAutoConfigClass() {
    return myAutoConfigClass;
  }

  @NotNull
  @Override
  public Module getModule() {
    return myModule;
  }

  @Nullable
  @Override
  public Set<String> getActiveProfiles() {
    return myActiveProfiles;
  }

  @Override
  public boolean processConfigurationValues(Processor<? super List<ConfigurationValueResult>> processor,
                                            boolean checkRelaxedNames,
                                            @NotNull MetaConfigKey configKey) {
    PsiManager psiManager = PsiManager.getInstance(getModule().getProject());
    Set<String> activeProfiles = SpringBootConfigValueSearcher.clearDefaultTestProfile(getActiveProfiles());
    ConfigurationValueSearchParams searchParams =
      new ConfigurationValueSearchParams(getModule(), checkRelaxedNames, activeProfiles, configKey);
    for (VirtualFile file : myConfigFilesCache.getValue()) {
      SpringBootModelConfigFileContributor contributor = SpringBootModelConfigFileContributor.getContributor(file);
      if (contributor == null) continue;

      PsiFile psiFile = psiManager.findFile(file);
      if (psiFile == null) continue;

      List<ConfigurationValueResult> values = contributor.findConfigurationValues(psiFile, searchParams);
      if (!processor.process(values)) return false;
    }
    return true;
  }
}

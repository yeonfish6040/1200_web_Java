package com.intellij.spring.boot.spi

import com.intellij.jam.JamStringAttributeElement
import com.intellij.openapi.module.ModuleUtilCore
import com.intellij.openapi.roots.ModuleRootManager
import com.intellij.openapi.util.TextRange
import com.intellij.psi.PsiClass
import com.intellij.psi.PsiElement
import com.intellij.psi.PsiLanguageInjectionHost
import com.intellij.psi.PsiReference
import com.intellij.spring.boot.library.SpringBootLibraryUtil
import com.intellij.spring.spi.SpringSpiClassesListJamConverter
import com.intellij.spring.spi.SpringSpiManager
import com.intellij.util.containers.ContainerUtil

class SpringBootSpiClassesListJamConverter(configKey: String,
                                           private val importKey: String) : SpringSpiClassesListJamConverter(configKey) {

  override fun createReferences(context: JamStringAttributeElement<PsiClass?>,
                                injectionHost: PsiLanguageInjectionHost): Array<PsiReference> {
    return arrayOf(SpringBootSpiClassReference(myConfigKey, importKey, injectionHost, null, context.stringValue))
  }

  class SpringBootSpiClassReference(configKey: String,
                                    private val importKey: String,
                                    literal: PsiElement,
                                    rangeInElement: TextRange?,
                                    text: String?) : SpringSpiClassReference(configKey, literal, rangeInElement, text) {
    override fun getRelevantClasses(literal: PsiElement?, configKey: String): List<PsiClass> {
      if (literal == null) return emptyList()

      val module = ModuleUtilCore.findModuleForPsiElement(literal) ?: return emptyList()

      val containingFile = literal.containingFile.originalFile.virtualFile
      val isInTest = containingFile != null &&
                     ModuleRootManager.getInstance(module).fileIndex.isInTestSourceContent(containingFile)

      val result = SpringSpiManager.getInstance(module).getClassesListValue(isInTest, configKey)
      if (!SpringBootLibraryUtil.isAtLeastVersion(module, SpringBootLibraryUtil.SpringBootVersion.VERSION_2_7_0)) {
        return result
      }
      val imports = SpringBootImportsManager.getInstance(module).getClasses(isInTest, importKey)
      return ContainerUtil.concat(result, imports)
    }
  }
}
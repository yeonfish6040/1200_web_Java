package com.intellij.spring.boot.model.autoconfigure.jam;

import com.intellij.jam.JamBaseElement;
import com.intellij.jam.JamService;
import com.intellij.jam.reflect.*;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.NullableLazyValue;
import com.intellij.psi.PsiAnnotation;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElementRef;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.semantic.SemKey;
import com.intellij.spring.model.aliasFor.SpringAliasForUtils;
import com.intellij.spring.model.jam.SpringSemContributorUtil;
import com.intellij.util.Function;
import com.intellij.util.containers.ConcurrentFactoryMap;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.intellij.spring.boot.model.autoconfigure.SpringBootAutoconfigureClassesConstants.IMPORT_AUTO_CONFIGURATION;

public class ImportAutoConfiguration extends JamBaseElement<PsiClass> {
  private static final JamClassAttributeMeta.Collection VALUE =
    new JamClassAttributeMeta.Collection("value");
  private static final JamClassAttributeMeta.Collection CLASSES =
    new JamClassAttributeMeta.Collection("classes");
  private static final JamClassAttributeMeta.Collection EXCLUDE =
    new JamClassAttributeMeta.Collection("exclude");

  static final JamAnnotationArchetype ARCHETYPE =
    new JamAnnotationArchetype()
      .addAttribute(VALUE)
      .addAttribute(CLASSES)
      .addAttribute(EXCLUDE);

  private static final JamAnnotationMeta ANNOTATION_META = new JamAnnotationMeta(IMPORT_AUTO_CONFIGURATION, ARCHETYPE);

  public static final SemKey<ImportAutoConfiguration> JAM_KEY =
    JamService.JAM_ELEMENT_KEY.subKey("ImportAutoConfigSemKey");

  public static final JamClassMeta<ImportAutoConfiguration> META =
    new JamClassMeta<>(null, ImportAutoConfiguration.class, JAM_KEY)
      .addAnnotation(ANNOTATION_META);

  public static final SemKey<JamMemberMeta<PsiClass, ImportAutoConfiguration>> META_KEY =
    JamService.MEMBER_META_KEY.subKey("ImportAutoConfigurationMeta");

  private final String myAnno;
  private final PsiElementRef<PsiAnnotation> myAnnotationRef;
  private final NullableLazyValue<ImportAutoConfiguration> myDefiningMetaAnnotation =
    new NullableLazyValue<>() {
      @Nullable
      @Override
      protected ImportAutoConfiguration compute() {
        PsiAnnotation definingMetaAnnotation = SpringAliasForUtils
          .findDefiningMetaAnnotation(getPsiElement(), getAnnotationFqn(), IMPORT_AUTO_CONFIGURATION);
        if (definingMetaAnnotation != null) {
          PsiClass annotationType = PsiTreeUtil.getParentOfType(definingMetaAnnotation, PsiClass.class, true);
          if (annotationType != null) {
            return META.getJamElement(annotationType);
          }
        }
        return null;
      }
    };

  private static final Map<String, JamAnnotationMeta> ourJamAnnotationMetaMap =
    ConcurrentFactoryMap.createMap(key -> new JamAnnotationMeta(key, ARCHETYPE));

  @SuppressWarnings("unused")
  public ImportAutoConfiguration(@NotNull PsiClass psiClass) {
    this(IMPORT_AUTO_CONFIGURATION, psiClass);
  }

  public ImportAutoConfiguration(@Nullable String anno, @NotNull PsiClass psiClass) {
    super(PsiElementRef.real(psiClass));
    myAnno = anno;
    JamAnnotationMeta annotationMeta = ourJamAnnotationMetaMap.get(anno);
    myAnnotationRef = annotationMeta.getAnnotationRef(psiClass);
  }

  public static Function<Module, Collection<String>> getAnnotations() {
    return SpringSemContributorUtil.getCustomMetaAnnotations(IMPORT_AUTO_CONFIGURATION);
  }

  @NotNull
  public String getAnnotationFqn() {
    return myAnno;
  }

  @Nullable
  public PsiAnnotation getAnnotation() {
    return myAnnotationRef.getPsiElement();
  }

  public @Nullable String getSourceFqn() {
    if (IMPORT_AUTO_CONFIGURATION.equals(myAnno)) {
      return getPsiElement().getQualifiedName();
    }
    ImportAutoConfiguration definingMetaAnnotation = myDefiningMetaAnnotation.getValue();
    if (definingMetaAnnotation != null) {
      return definingMetaAnnotation.getPsiElement().getQualifiedName();
    }
    return null;
  }

  public List<PsiClass> getExcludes() {
    return ContainerUtil.mapNotNull(EXCLUDE.getJam(myAnnotationRef), element -> element.getValue());
  }

  public List<PsiClass> getClasses() {
    if (IMPORT_AUTO_CONFIGURATION.equals(myAnno)) {
      List<PsiClass> classes = ContainerUtil.mapNotNull(VALUE.getJam(myAnnotationRef), element -> element.getValue());
      if (!classes.isEmpty()) {
        return classes;
      }
      return ContainerUtil.mapNotNull(CLASSES.getJam(myAnnotationRef), element -> element.getValue());
    }
    ImportAutoConfiguration definingMetaAnnotation = myDefiningMetaAnnotation.getValue();
    if (definingMetaAnnotation != null) {
      return definingMetaAnnotation.getClasses();
    }
    return Collections.emptyList();
  }
}

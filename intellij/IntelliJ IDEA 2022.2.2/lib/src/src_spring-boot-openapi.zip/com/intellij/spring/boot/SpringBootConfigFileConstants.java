// Copyright 2000-2017 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot;

public final class SpringBootConfigFileConstants {

  public static final String APPLICATION = "application";

  public static final String APPLICATION_PROPERTIES = APPLICATION + ".properties";
  public static final String APPLICATION_YML = APPLICATION + ".yml";

  public static final String BOOTSTRAP = "bootstrap";
  public static final String BOOTSTRAP_PROPERTIES = BOOTSTRAP + ".properties";

  public static final String SPRING_CONFIGURATION_METADATA_JSON = "spring-configuration-metadata.json";
  public static final String ADDITIONAL_SPRING_CONFIGURATION_METADATA_JSON = "additional-spring-configuration-metadata.json";
}

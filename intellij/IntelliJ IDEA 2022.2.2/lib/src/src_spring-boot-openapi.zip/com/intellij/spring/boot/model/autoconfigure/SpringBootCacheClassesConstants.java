package com.intellij.spring.boot.model.autoconfigure;

import org.jetbrains.annotations.NonNls;

public interface SpringBootCacheClassesConstants {
  @NonNls String CACHE_CONFIGURATION_IMPORT_SELECTOR =
    "org.springframework.boot.autoconfigure.cache.CacheAutoConfiguration.CacheConfigurationImportSelector";

  @NonNls String GENERIC_CACHE_CONFIGURATION = "org.springframework.boot.autoconfigure.cache.GenericCacheConfiguration";
  @NonNls String EL_CACHE_CACHE_CONFIGURATION = "org.springframework.boot.autoconfigure.cache.EhCacheCacheConfiguration";
  @NonNls String HAZELCAST_CACHE_CONFIGURATION = "org.springframework.boot.autoconfigure.cache.HazelcastCacheConfiguration";
  @NonNls String INFINISPAN_CACHE_CONFIGURATION = "org.springframework.boot.autoconfigure.cache.InfinispanCacheConfiguration";
  @NonNls String JCACHE_CACHE_CONFIGURATION = "org.springframework.boot.autoconfigure.cache.JCacheCacheConfiguration";
  @NonNls String COUCHBASE_CACHE_CONFIGURATION = "org.springframework.boot.autoconfigure.cache.CouchbaseCacheConfiguration";
  @NonNls String REDIS_CACHE_CONFIGURATION = "org.springframework.boot.autoconfigure.cache.RedisCacheConfiguration";
  @NonNls String CAFFEINE_CACHE_CONFIGURATION = "org.springframework.boot.autoconfigure.cache.CaffeineCacheConfiguration";
  @NonNls String SIMPLE_CACHE_CONFIGURATION = "org.springframework.boot.autoconfigure.cache.SimpleCacheConfiguration";
}
